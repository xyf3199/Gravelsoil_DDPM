import os
import numpy as np
from PIL import Image
from tqdm import tqdm
import random

# ============== 请修改以下路径 ==============
SLICE_DIR = "/mnt/66"  # 包含彩色切片的文件夹
OUTPUT_DIR = "/mnt/PyCharm_Project_4/6/3d_blocks_random/512"  # 保存3D块的文件夹
# ==========================================

BLOCK_SIZE = 512  # 固定块大小为256x256x256
NUM_BLOCKS = 2000  # 生成2000个随机块
RANDOM_SEED = 42  # 随机种子，设为None禁用
VISUALIZE_SAMPLES = 5  # 可视化示例数量


def generate_random_colored_volume_blocks():
    """随机生成固定大小的3D体数据块"""
    # 确保输出目录存在
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    vis_dir = os.path.join(OUTPUT_DIR, "visualizations")
    os.makedirs(vis_dir, exist_ok=True)

    # 设置随机种子
    if RANDOM_SEED is not None:
        random.seed(RANDOM_SEED)
        np.random.seed(RANDOM_SEED)
        print(f"已设置随机种子: {RANDOM_SEED}")

    # 获取切片文件并排序
    slice_files = sorted([
        f for f in os.listdir(SLICE_DIR)
        if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tif', '.tiff'))
    ])

    if not slice_files:
        print(f"错误：在{SLICE_DIR}中未找到图像文件")
        return

    num_slices = len(slice_files)
    slice_size = Image.open(os.path.join(SLICE_DIR, slice_files[0])).size[0]

    print(f"找到 {num_slices} 个切片，尺寸: {slice_size}x{slice_size}")

    # 检查是否能生成足够的块
    if num_slices < BLOCK_SIZE or slice_size < BLOCK_SIZE:
        print(f"错误：数据尺寸不足，需要至少{BLOCK_SIZE}个切片且切片尺寸至少为{BLOCK_SIZE}x{BLOCK_SIZE}")
        return

    print(f"将随机生成 {NUM_BLOCKS} 个3D块（尺寸: {BLOCK_SIZE}x{BLOCK_SIZE}x{BLOCK_SIZE}）")

    vis_info = []  # 存储可视化信息

    # 生成随机块
    pbar = tqdm(total=NUM_BLOCKS, desc="生成随机3D块")
    for block_idx in range(NUM_BLOCKS):
        # 随机选择起始位置
        z_start = random.randint(0, num_slices - BLOCK_SIZE)
        x_start = random.randint(0, slice_size - BLOCK_SIZE)
        y_start = random.randint(0, slice_size - BLOCK_SIZE)

        # 创建立方体块
        volume_block = np.zeros(
            (BLOCK_SIZE, BLOCK_SIZE, BLOCK_SIZE, 3),
            dtype=np.uint8
        )

        # 填充每个深度的切片
        for z in range(BLOCK_SIZE):
            slice_idx = z_start + z
            img_path = os.path.join(SLICE_DIR, slice_files[slice_idx])
            try:
                img = Image.open(img_path).convert('RGB')
                img_array = np.array(img)

                # 裁剪固定大小的区域
                cropped = img_array[y_start:y_start + BLOCK_SIZE, x_start:x_start + BLOCK_SIZE]
                volume_block[z] = cropped
            except Exception as e:
                print(f"读取切片{img_path}失败: {e}")
                # 如果读取失败，填充黑色
                volume_block[z] = np.zeros((BLOCK_SIZE, BLOCK_SIZE, 3), dtype=np.uint8)

        # 保存3D块
        block_file = os.path.join(
            OUTPUT_DIR,
            f"volume_block_{block_idx:05d}.npz"
        )
        np.savez_compressed(block_file,
                            volume=volume_block,
                            z_start=z_start,
                            x_start=x_start,
                            y_start=y_start)  # 保存起始位置信息

        # 记录可视化信息
        if block_idx < VISUALIZE_SAMPLES:
            vis_info.append({
                "index": block_idx,
                "z_start": z_start,
                "x_start": x_start,
                "y_start": y_start,
                "file": block_file
            })

        pbar.update(1)

    pbar.close()

    print(f"成功生成 {NUM_BLOCKS} 个3D块，保存至 {OUTPUT_DIR}")

    # 生成可视化示例
    if vis_info and VISUALIZE_SAMPLES > 0:
        visualize_blocks(vis_info, SLICE_DIR, slice_files, vis_dir, VISUALIZE_SAMPLES)


def visualize_blocks(vis_info, slice_dir, slice_files, vis_dir, num_samples):
    """可视化3D块的切片和原始位置"""
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("警告：未安装matplotlib，无法生成可视化")
        return

    print(f"生成{min(num_samples, len(vis_info))}个可视化示例...")

    for info in vis_info[:num_samples]:
        try:
            data = np.load(info["file"])
            volume = data["volume"]
            depth, height, width, _ = volume.shape

            # 可视化块内切片
            fig, axes = plt.subplots(3, 3, figsize=(15, 15))
            depths = [int(depth * i / 8) for i in range(9)]

            for i, z in enumerate(depths):
                ax = axes[i // 3, i % 3]
                ax.imshow(volume[z])
                ax.set_title(f"深度:{z}/{depth}")
                ax.axis('off')

            vis_path = os.path.join(vis_dir, f"block_{info['index']}_slices.png")
            plt.savefig(vis_path, bbox_inches='tight', dpi=150)
            plt.close()

            # 可视化原始切片位置
            fig, axes = plt.subplots(1, 3, figsize=(20, 10))
            z_depths = [info["z_start"], info["z_start"] + depth // 2, info["z_start"] + depth - 1]

            for i, z in enumerate(z_depths):
                if z >= len(slice_files):
                    continue

                img_path = os.path.join(slice_dir, slice_files[z])
                img = np.array(Image.open(img_path).convert('RGB'))
                ax = axes[i]
                ax.imshow(img)

                rect = plt.Rectangle(
                    (info["x_start"], info["y_start"]),
                    width, height,
                    linewidth=3, edgecolor='red', facecolor='none'
                )
                ax.add_patch(rect)
                ax.set_title(f"切片{z} (深度{i + 1}/3)")
                ax.axis('off')

            plt.suptitle(f"块位置: Z={info['z_start']}, X={info['x_start']}, Y={info['y_start']}")
            vis_origin = os.path.join(vis_dir, f"block_{info['index']}_origin.png")
            plt.savefig(vis_origin, bbox_inches='tight', dpi=150)
            plt.close()

        except Exception as e:
            print(f"可视化失败: {e}")


if __name__ == "__main__":
    print("开始生成3D彩色体数据块...")
    generate_random_colored_volume_blocks()
    print("处理完成！")