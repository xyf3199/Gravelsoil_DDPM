# create_high_quality_128_data.py
import numpy as np
import os
from tqdm import tqdm
from scipy import ndimage


def create_high_quality_128_data():
    """创建高质量的128尺寸训练数据"""
    input_dir = "/mnt/PyCharm_Project_4/6/3d_blocks_random/512"
    output_dir = "/mnt/PyCharm_Project_4/6/3d_blocks_random/128_high_quality"
    os.makedirs(output_dir, exist_ok=True)

    input_files = [f for f in os.listdir(input_dir) if f.endswith('.npz')]

    print("创建高质量128训练数据...")
    print(f"输入目录: {input_dir}")
    print(f"输出目录: {output_dir}")
    print(f"找到 {len(input_files)} 个输入文件")

    for file in tqdm(input_files, desc="处理512->128压缩"):
        input_path = os.path.join(input_dir, file)
        output_path = os.path.join(output_dir, f"compressed_{file}")

        try:
            with np.load(input_path) as data:
                volume = data['volume']  # (512,512,512,3)

            # 高质量压缩策略：
            # 1. 先对每个通道单独处理
            compressed_channels = []
            for channel in range(3):
                channel_data = volume[..., channel]

                # 使用高斯平滑减少噪声
                smoothed = ndimage.gaussian_filter(channel_data, sigma=0.8)

                # 高质量下采样（5阶样条插值）
                zoom_factors = (128 / 512, 128 / 512, 128 / 512)
                compressed_channel = ndimage.zoom(smoothed, zoom_factors, order=5)
                compressed_channels.append(compressed_channel)

            # 合并通道
            compressed = np.stack(compressed_channels, axis=-1)
            compressed = np.clip(compressed, 0, 255).astype(np.uint8)

            # 保存压缩后的数据
            np.savez_compressed(
                output_path,
                volume=compressed,
                original_shape=volume.shape,
                compressed_shape=compressed.shape,
                method="高质量128压缩(5阶样条+高斯平滑)"
            )

        except Exception as e:
            print(f"处理文件 {file} 时出错: {e}")
            continue

    print(f"高质量128数据创建完成! 输出目录: {output_dir}")
    print(f"共处理 {len(input_files)} 个文件")

    # 验证输出
    output_files = [f for f in os.listdir(output_dir) if f.endswith('.npz')]
    print(f"生成 {len(output_files)} 个压缩文件")

    return output_dir


def check_compression_quality():
    """检查压缩质量"""
    output_dir = "/mnt/PyCharm_Project_4/6/3d_blocks_random/128_high_quality"

    if not os.path.exists(output_dir):
        print("输出目录不存在，请先运行压缩函数")
        return

    output_files = [f for f in os.listdir(output_dir) if f.endswith('.npz')]

    if not output_files:
        print("没有找到压缩文件")
        return

    # 检查第一个文件的质量
    sample_file = os.path.join(output_dir, output_files[0])

    try:
        with np.load(sample_file) as data:
            compressed_volume = data['volume']
            original_shape = data['original_shape']
            compressed_shape = data['compressed_shape']
            method = data['method']

        print("压缩质量检查:")
        print(f"原始形状: {original_shape}")
        print(f"压缩形状: {compressed_shape}")
        print(f"压缩方法: {method}")
        print(f"数据范围: [{compressed_volume.min()}, {compressed_volume.max()}]")
        print(f"数据类型: {compressed_volume.dtype}")
        print(f"压缩比例: {original_shape[0] / compressed_shape[0]:.1f}:1")

        # 检查数据统计
        print("\n数据统计:")
        for channel in range(3):
            channel_data = compressed_volume[..., channel]
            print(f"通道 {channel}: 均值={channel_data.mean():.2f}, 标准差={channel_data.std():.2f}")

    except Exception as e:
        print(f"检查压缩质量时出错: {e}")


if __name__ == "__main__":
    # 创建高质量128数据
    output_dir = create_high_quality_128_data()

    # 检查压缩质量
    check_compression_quality()

    print("\n压缩过程完成!")