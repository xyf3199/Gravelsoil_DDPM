import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import matplotlib.pyplot as plt
import json
from datetime import datetime

# ============== 定义保存路径 ==============
SAVE_DIR = "/mnt/PyCharm_Project_4/6optimized_3d_diffusion_64channels"
CHECKPOINT_DIR = os.path.join(SAVE_DIR, "checkpoints")
VISUALIZATION_DIR = os.path.join(SAVE_DIR, "visualizations")
LOG_DIR = os.path.join(SAVE_DIR, "logs")

# 创建所有必要的目录
os.makedirs(SAVE_DIR, exist_ok=True)
os.makedirs(CHECKPOINT_DIR, exist_ok=True)
os.makedirs(VISUALIZATION_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)


class ThreeDBlockDataset(Dataset):
    """改进的3D块数据集 - 更保守的数据增强策略"""

    def __init__(self, data_dir, transform=None, convert_to_grayscale=False, augment=False):
        self.data_dir = data_dir
        self.transform = transform
        self.convert_to_grayscale = convert_to_grayscale
        self.augment = augment
        self.block_files = [f for f in os.listdir(data_dir) if f.endswith('.npz')]
        print(f"找到 {len(self.block_files)} 个数据文件")

    def __len__(self):
        return len(self.block_files)

    def __getitem__(self, idx):
        try:
            # 加载数据
            data = np.load(os.path.join(self.data_dir, self.block_files[idx]))
            volume = data['volume'].astype(np.float32) / 255.0
            volume = volume.copy()  # 确保内存连续

            # 确保尺寸为128×128×128
            if volume.shape[:3] != (128, 128, 128):
                volume = self._resize_volume(volume, target_size=128)

            # 更保守的数据增强 - 只在训练时使用，且概率更低
            if self.augment:
                volume = self._conservative_augment_volume(volume)

            # 转换为灰度图（如果需要）
            if self.convert_to_grayscale and volume.shape[-1] > 1:
                volume = self._to_grayscale(volume)

            # 转换为PyTorch tensor (C, D, H, W)
            volume_tensor = torch.from_numpy(volume).permute(3, 0, 1, 2)

            if self.transform:
                volume_tensor = self.transform(volume_tensor)

            return volume_tensor

        except Exception as e:
            print(f"加载文件 {self.block_files[idx]} 时出错: {e}")
            return self.__getitem__((idx + 1) % len(self.block_files))

    def _resize_volume(self, volume, target_size=128):
        """调整体积到目标尺寸"""
        from scipy.ndimage import zoom
        depth, height, width, channels = volume.shape
        zoom_factors = (
            target_size / depth,
            target_size / height,
            target_size / width,
            1
        )
        resized_volume = zoom(volume, zoom_factors, order=1)
        return resized_volume.astype(np.float32).copy()

    def _to_grayscale(self, volume):
        """将多通道体积转换为单通道灰度图"""
        if volume.shape[-1] == 3:
            gray = np.dot(volume[..., :3], [0.2989, 0.5870, 0.1140])
        elif volume.shape[-1] == 4:
            gray = np.dot(volume[..., :3], [0.2989, 0.5870, 0.1140])
        else:
            gray = np.mean(volume, axis=-1)
        gray = gray[..., np.newaxis]
        return gray.astype(np.float32).copy()

    def _conservative_augment_volume(self, volume):
        """保守的数据增强策略 - 保持原始特征"""
        augmented = volume.copy()

        # 只进行轻微的增强，避免破坏3D结构
        # 1. 小角度旋转 (只使用0°和180°，避免90°和270°破坏结构)
        if np.random.random() > 0.7:  # 30%概率
            k = np.random.choice([0, 2])  # 只选择0°或180°旋转
            augmented = np.rot90(augmented, k, axes=(1, 2))

        # 2. 只在水平方向翻转 (避免垂直翻转破坏空间关系)
        if np.random.random() > 0.7:  # 30%概率
            augmented = np.flip(augmented, axis=2)  # 只翻转宽度维度

        # 3. 轻微的亮度调整
        if np.random.random() > 0.8:  # 20%概率
            brightness_factor = np.random.uniform(0.9, 1.1)
            augmented = np.clip(augmented * brightness_factor, 0, 1)

        # 关键修复：确保返回连续数组
        return np.ascontiguousarray(augmented)


class TimeEmbedding(nn.Module):
    """时间步嵌入"""

    def __init__(self, dim):
        super().__init__()
        self.dim = dim
        self.proj = nn.Sequential(
            nn.Linear(dim, dim * 2),
            nn.SiLU(),
            nn.Linear(dim * 2, dim)
        )

    def forward(self, timesteps):
        half_dim = self.dim // 2
        emb = torch.log(torch.tensor(10000.0)) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, device=timesteps.device) * -emb)
        emb = timesteps[:, None] * emb[None, :]
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=-1)
        return self.proj(emb)


class ResidualBlock3D(nn.Module):
    """3D残差块"""

    def __init__(self, in_channels, out_channels, time_emb_dim=None):
        super().__init__()
        self.time_emb_dim = time_emb_dim

        self.conv1 = nn.Conv3d(in_channels, out_channels, 3, padding=1)
        self.norm1 = nn.GroupNorm(8, out_channels)
        self.conv2 = nn.Conv3d(out_channels, out_channels, 3, padding=1)
        self.norm2 = nn.GroupNorm(8, out_channels)

        if in_channels != out_channels:
            self.shortcut = nn.Conv3d(in_channels, out_channels, 1)
        else:
            self.shortcut = nn.Identity()

        if time_emb_dim is not None:
            self.time_emb_proj = nn.Linear(time_emb_dim, out_channels)

        self.activation = nn.SiLU()

    def forward(self, x, t_emb=None):
        residual = self.shortcut(x)

        x = self.conv1(x)
        x = self.norm1(x)

        if t_emb is not None and self.time_emb_dim is not None:
            t_emb = self.time_emb_proj(self.activation(t_emb))
            t_emb = t_emb.view(t_emb.shape[0], t_emb.shape[1], 1, 1, 1)
            x = x + t_emb

        x = self.activation(x)
        x = self.conv2(x)
        x = self.norm2(x)

        return self.activation(x + residual)


class AttentionBlock3D(nn.Module):
    """3D注意力块"""

    def __init__(self, channels):
        super().__init__()
        self.norm = nn.GroupNorm(8, channels)
        self.qkv = nn.Conv3d(channels, channels * 3, 1)
        self.proj = nn.Conv3d(channels, channels, 1)

    def forward(self, x):
        B, C, D, H, W = x.shape
        residual = x

        x = self.norm(x)
        qkv = self.qkv(x).reshape(B, 3, C, -1)
        q, k, v = qkv[:, 0], qkv[:, 1], qkv[:, 2]

        # 简化版注意力计算
        scale = (C * D * H * W) ** 0.25
        attn = torch.einsum('bci,bcj->bij', q / scale, k / scale)
        attn = F.softmax(attn, dim=-1)

        x = torch.einsum('bij,bcj->bci', attn, v)
        x = x.reshape(B, C, D, H, W)
        x = self.proj(x)

        return x + residual


class SimpleConvBlock3D(nn.Module):
    """简单的3D卷积块（无残差连接）"""

    def __init__(self, in_channels, out_channels, time_emb_dim=None):
        super().__init__()
        self.conv1 = nn.Conv3d(in_channels, out_channels, 3, padding=1)
        self.norm1 = nn.GroupNorm(8, out_channels)
        self.conv2 = nn.Conv3d(out_channels, out_channels, 3, padding=1)
        self.norm2 = nn.GroupNorm(8, out_channels)

        if time_emb_dim is not None:
            self.time_emb_proj = nn.Linear(time_emb_dim, out_channels)

        self.activation = nn.SiLU()

    def forward(self, x, t_emb=None):
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.activation(x)

        if t_emb is not None:
            t_emb = self.time_emb_proj(self.activation(t_emb))
            t_emb = t_emb.view(t_emb.shape[0], t_emb.shape[1], 1, 1, 1)
            x = x + t_emb

        x = self.conv2(x)
        x = self.norm2(x)
        x = self.activation(x)

        return x


class ThreeDUNet128Ablation(nn.Module):
    """支持消融实验的3D U-Net"""

    def __init__(self, in_channels=3, base_channels=64, time_emb_dim=128, config=None):  # 修改：默认使用64通道
        super().__init__()

        # 默认配置
        if config is None:
            config = {
                "use_time_embedding": True,
                "use_residual_blocks": True,
                "use_attention": False,
                "use_group_norm": True
            }

        self.config = config

        # 时间步嵌入
        self.time_emb_dim = time_emb_dim
        if config["use_time_embedding"]:
            self.time_embed = TimeEmbedding(time_emb_dim)
        else:
            self.time_embed = None

        # 编码器
        if config["use_residual_blocks"]:
            self.enc1 = ResidualBlock3D(in_channels, base_channels,
                                       time_emb_dim if config["use_time_embedding"] else None)
            self.enc2 = ResidualBlock3D(base_channels, base_channels * 2,
                                       time_emb_dim if config["use_time_embedding"] else None)
            self.enc3 = ResidualBlock3D(base_channels * 2, base_channels * 4,
                                       time_emb_dim if config["use_time_embedding"] else None)
            self.enc4 = ResidualBlock3D(base_channels * 4, base_channels * 8,
                                       time_emb_dim if config["use_time_embedding"] else None)
        else:
            self.enc1 = SimpleConvBlock3D(in_channels, base_channels,
                                         time_emb_dim if config["use_time_embedding"] else None)
            self.enc2 = SimpleConvBlock3D(base_channels, base_channels * 2,
                                         time_emb_dim if config["use_time_embedding"] else None)
            self.enc3 = SimpleConvBlock3D(base_channels * 2, base_channels * 4,
                                         time_emb_dim if config["use_time_embedding"] else None)
            self.enc4 = SimpleConvBlock3D(base_channels * 4, base_channels * 8,
                                         time_emb_dim if config["use_time_embedding"] else None)

        # 中间层
        if config["use_residual_blocks"]:
            self.mid1 = ResidualBlock3D(base_channels * 8, base_channels * 8,
                                       time_emb_dim if config["use_time_embedding"] else None)
            self.mid2 = ResidualBlock3D(base_channels * 8, base_channels * 8,
                                       time_emb_dim if config["use_time_embedding"] else None)
        else:
            self.mid1 = SimpleConvBlock3D(base_channels * 8, base_channels * 8,
                                         time_emb_dim if config["use_time_embedding"] else None)
            self.mid2 = SimpleConvBlock3D(base_channels * 8, base_channels * 8,
                                         time_emb_dim if config["use_time_embedding"] else None)

        # 注意力机制
        if config["use_attention"]:
            self.attention = AttentionBlock3D(base_channels * 8)

        # 解码器
        if config["use_residual_blocks"]:
            self.dec4 = ResidualBlock3D(base_channels * 8 + base_channels * 4, base_channels * 4,
                                       time_emb_dim if config["use_time_embedding"] else None)
            self.dec3 = ResidualBlock3D(base_channels * 4 + base_channels * 2, base_channels * 2,
                                       time_emb_dim if config["use_time_embedding"] else None)
            self.dec2 = ResidualBlock3D(base_channels * 2 + base_channels, base_channels,
                                       time_emb_dim if config["use_time_embedding"] else None)
            self.dec1 = ResidualBlock3D(base_channels, base_channels,
                                       time_emb_dim if config["use_time_embedding"] else None)
        else:
            self.dec4 = SimpleConvBlock3D(base_channels * 8 + base_channels * 4, base_channels * 4,
                                         time_emb_dim if config["use_time_embedding"] else None)
            self.dec3 = SimpleConvBlock3D(base_channels * 4 + base_channels * 2, base_channels * 2,
                                         time_emb_dim if config["use_time_embedding"] else None)
            self.dec2 = SimpleConvBlock3D(base_channels * 2 + base_channels, base_channels,
                                         time_emb_dim if config["use_time_embedding"] else None)
            self.dec1 = SimpleConvBlock3D(base_channels, base_channels,
                                         time_emb_dim if config["use_time_embedding"] else None)

        self.final_conv = nn.Conv3d(base_channels, in_channels, kernel_size=1)

        self.downsample = nn.MaxPool3d(2)
        self.upsample = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=True)

    def forward(self, x, timesteps):
        # 时间步嵌入
        if self.time_embed is not None:
            t_emb = self.time_embed(timesteps)
        else:
            t_emb = None

        # 编码器
        e1 = self.enc1(x, t_emb)
        e2 = self.enc2(self.downsample(e1), t_emb)
        e3 = self.enc3(self.downsample(e2), t_emb)
        e4 = self.enc4(self.downsample(e3), t_emb)

        # 中间层
        m = self.mid1(e4, t_emb)

        # 注意力机制
        if hasattr(self, 'attention'):
            m = self.attention(m)

        m = self.mid2(m, t_emb)

        # 解码器
        d4 = self.upsample(m)
        d4 = self.dec4(torch.cat([d4, e3], dim=1), t_emb)

        d3 = self.upsample(d4)
        d3 = self.dec3(torch.cat([d3, e2], dim=1), t_emb)

        d2 = self.upsample(d3)
        d2 = self.dec2(torch.cat([d2, e1], dim=1), t_emb)

        d1 = self.dec1(d2, t_emb)

        return self.final_conv(d1)


class Diffusion3DTrainer128:
    """改进的3D扩散模型训练器"""

    def __init__(self, model, device, T=1000, beta_start=1e-4, beta_end=0.02):
        self.model = model.to(device)
        self.device = device
        self.T = T

        # 线性噪声调度（更稳定）
        self.betas = torch.linspace(beta_start, beta_end, T).to(device)
        self.alphas = 1. - self.betas
        self.alphas_cumprod = torch.cumprod(self.alphas, dim=0)
        self.alphas_cumprod_prev = F.pad(self.alphas_cumprod[:-1], (1, 0), value=1.0)

        # 预计算系数
        self.sqrt_alphas_cumprod = torch.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(1. - self.alphas_cumprod)
        self.sqrt_recip_alphas = torch.sqrt(1.0 / self.alphas)
        self.posterior_variance = self.betas * (1. - self.alphas_cumprod_prev) / (1. - self.alphas_cumprod)

    def forward_diffusion(self, x0, t):
        """前向扩散过程"""
        noise = torch.randn_like(x0)
        sqrt_alphas_cumprod_t = self.sqrt_alphas_cumprod[t].view(-1, 1, 1, 1, 1)
        sqrt_one_minus_alphas_cumprod_t = self.sqrt_one_minus_alphas_cumprod[t].view(-1, 1, 1, 1, 1)
        xt = sqrt_alphas_cumprod_t * x0 + sqrt_one_minus_alphas_cumprod_t * noise
        return xt, noise

    def train_epoch(self, dataloader, optimizer, epoch):
        """训练一个epoch"""
        self.model.train()
        total_loss = 0
        num_batches = 0

        pbar = tqdm(dataloader, desc=f"Epoch {epoch}")
        for batch in pbar:
            try:
                x0 = batch.to(self.device)
                optimizer.zero_grad()

                # 随机采样时间步
                t = torch.randint(0, self.T, (x0.shape[0],), device=self.device)

                # 前向扩散
                xt, noise = self.forward_diffusion(x0, t)

                # 预测噪声
                predicted_noise = self.model(xt, t)

                # 计算损失
                loss = F.mse_loss(predicted_noise, noise)
                loss.backward()

                # 梯度裁剪
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                optimizer.step()

                total_loss += loss.item()
                num_batches += 1
                pbar.set_postfix({"Loss": f"{loss.item():.6f}"})

            except RuntimeError as e:
                if "out of memory" in str(e):
                    print("内存不足，跳过该批次")
                    torch.cuda.empty_cache()
                    continue
                else:
                    raise e

        return total_loss / num_batches if num_batches > 0 else float('inf')

    def sample(self, shape, num_samples=1):
        """采样生成新的3D块"""
        self.model.eval()
        with torch.no_grad():
            # 从纯噪声开始
            x = torch.randn((num_samples, *shape), device=self.device)

            for t in tqdm(range(self.T - 1, -1, -1), desc="Sampling"):
                t_batch = torch.full((num_samples,), t, device=self.device, dtype=torch.long)

                # 预测噪声
                predicted_noise = self.model(x, t_batch)

                # 计算系数
                alpha = self.alphas[t]
                alpha_cumprod = self.alphas_cumprod[t]
                alpha_cumprod_prev = self.alphas_cumprod_prev[t]
                beta = self.betas[t]

                # 计算均值和方差
                sqrt_recip_alpha = self.sqrt_recip_alphas[t]
                sqrt_one_minus_alpha_cumprod = self.sqrt_one_minus_alphas_cumprod[t]

                # 计算均值
                model_mean = sqrt_recip_alpha * (
                        x - beta * predicted_noise / sqrt_one_minus_alpha_cumprod
                )

                if t == 0:
                    x = model_mean
                else:
                    posterior_variance = self.posterior_variance[t]
                    noise = torch.randn_like(x)
                    x = model_mean + torch.sqrt(posterior_variance) * noise

                # 清理内存
                if t % 100 == 0:
                    torch.cuda.empty_cache()

            return x


class Diffusion3DTrainer128Ablation(Diffusion3DTrainer128):
    """支持消融实验的扩散模型训练器"""

    def __init__(self, model, device, T=1000, noise_schedule="linear"):
        super().__init__(model, device, T)

        # 不同的噪声调度
        if noise_schedule == "linear":
            # 线性调度（默认）
            self.betas = torch.linspace(1e-4, 0.02, T).to(device)
        elif noise_schedule == "cosine":
            # 余弦调度
            self.betas = self._cosine_beta_schedule(T).to(device)
        elif noise_schedule == "quadratic":
            # 二次调度
            self.betas = torch.linspace(1e-4 ** 0.5, 0.02 ** 0.5, T).to(device) ** 2

        self.alphas = 1. - self.betas
        self.alphas_cumprod = torch.cumprod(self.alphas, dim=0)
        self.alphas_cumprod_prev = F.pad(self.alphas_cumprod[:-1], (1, 0), value=1.0)

        # 预计算系数
        self.sqrt_alphas_cumprod = torch.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(1. - self.alphas_cumprod)
        self.sqrt_recip_alphas = torch.sqrt(1.0 / self.alphas)
        self.posterior_variance = self.betas * (1. - self.alphas_cumprod_prev) / (1. - self.alphas_cumprod)

    def _cosine_beta_schedule(self, timesteps, s=0.008):
        """余弦噪声调度"""
        steps = timesteps + 1
        x = torch.linspace(0, timesteps, steps)
        alphas_cumprod = torch.cos(((x / timesteps) + s) / (1 + s) * torch.pi * 0.5) ** 2
        alphas_cumprod = alphas_cumprod / alphas_cumprod[0]
        betas = 1 - (alphas_cumprod[1:] / alphas_cumprod[:-1])
        return torch.clip(betas, 0, 0.999)


class AblationConfig:
    """消融实验配置"""

    def __init__(self):
        self.experiments = {
            "baseline": {  # 现在使用64通道作为基线
                "use_time_embedding": True,
                "use_residual_blocks": True,
                "use_attention": False,
                "use_group_norm": True,
                "noise_schedule": "linear",
                "use_data_augmentation": False,
                "num_diffusion_steps": 1000,
                "base_channels": 64,  # 64通道作为基线
                "description": "基线配置（64通道）"
            },
            "fewer_channels": {  # 原来的基线配置（32通道）作为消融实验
                "use_time_embedding": True,
                "use_residual_blocks": True,
                "use_attention": False,
                "use_group_norm": True,
                "noise_schedule": "linear",
                "use_data_augmentation": False,
                "num_diffusion_steps": 1000,
                "base_channels": 32,  # 32通道作为消融实验
                "description": "较少通道（32通道）"
            },
            "no_time_embedding": {
                "use_time_embedding": False,
                "use_residual_blocks": True,
                "use_attention": False,
                "use_group_norm": True,
                "noise_schedule": "linear",
                "use_data_augmentation": False,
                "num_diffusion_steps": 1000,
                "base_channels": 64,
                "description": "移除时间嵌入"
            },
            "no_residual_blocks": {
                "use_time_embedding": True,
                "use_residual_blocks": False,
                "use_attention": False,
                "use_group_norm": True,
                "noise_schedule": "linear",
                "use_data_augmentation": False,
                "num_diffusion_steps": 1000,
                "base_channels": 64,
                "description": "移除残差连接"
            },
            "with_attention": {
                "use_time_embedding": True,
                "use_residual_blocks": True,
                "use_attention": True,
                "use_group_norm": True,
                "noise_schedule": "linear",
                "use_data_augmentation": False,
                "num_diffusion_steps": 1000,
                "base_channels": 64,
                "description": "加入注意力机制"
            },
            "cosine_noise_schedule": {
                "use_time_embedding": True,
                "use_residual_blocks": True,
                "use_attention": False,
                "use_group_norm": True,
                "noise_schedule": "cosine",
                "use_data_augmentation": False,
                "num_diffusion_steps": 1000,
                "base_channels": 64,
                "description": "余弦噪声调度"
            },
            "with_augmentation": {
                "use_time_embedding": True,
                "use_residual_blocks": True,
                "use_attention": False,
                "use_group_norm": True,
                "noise_schedule": "linear",
                "use_data_augmentation": True,
                "num_diffusion_steps": 1000,
                "base_channels": 64,
                "description": "使用数据增强"
            },
            "fewer_steps": {
                "use_time_embedding": True,
                "use_residual_blocks": True,
                "use_attention": False,
                "use_group_norm": True,
                "noise_schedule": "linear",
                "use_data_augmentation": False,
                "num_diffusion_steps": 200,
                "base_channels": 64,
                "description": "较少扩散步数"
            }
            # 注意：我们删除了原来的"more_channels"实验，因为现在64通道是基线
        }


def save_checkpoint(epoch, model, optimizer, scheduler, train_losses, best_loss, filename):
    """保存训练检查点"""
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict() if scheduler else None,
        'train_losses': train_losses,
        'best_loss': best_loss,
    }
    torch.save(checkpoint, os.path.join(CHECKPOINT_DIR, filename))
    print(f"检查点已保存: {filename}")


def load_checkpoint(model, optimizer, scheduler, filename):
    """加载训练检查点"""
    checkpoint_path = os.path.join(CHECKPOINT_DIR, filename)
    if not os.path.exists(checkpoint_path):
        print(f"检查点文件不存在: {checkpoint_path}")
        return None, None, None, None, None

    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    if scheduler and checkpoint['scheduler_state_dict']:
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])

    print(f"从检查点恢复训练: {filename}, 起始epoch: {checkpoint['epoch']}")
    return checkpoint['epoch'], checkpoint['train_losses'], checkpoint['best_loss']


def save_training_log(train_losses, config):
    """保存训练日志和配置"""
    # 保存损失历史
    loss_log_path = os.path.join(LOG_DIR, "training_losses.json")
    with open(loss_log_path, 'w') as f:
        json.dump(train_losses, f, indent=2)

    # 保存训练配置
    config_log_path = os.path.join(LOG_DIR, "training_config.json")
    with open(config_log_path, 'w') as f:
        json.dump(config, f, indent=2)

    # 绘制损失曲线
    plt.figure(figsize=(10, 6))
    plt.plot(train_losses)
    plt.title('Improved 128×128×128 3D Diffusion Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.grid(True)
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'improved_3d_diffusion_128_training_loss.png'),
                bbox_inches='tight', dpi=150)
    plt.close()


def train_improved_3d_diffusion_model_128(resume_from_checkpoint=None):
    """改进的128×128×128 3D扩散模型训练"""
    # 配置参数
    DATA_DIR = "/mnt/128_high_quality6"
    BATCH_SIZE = 1  # 使用更小的批次确保稳定性
    EPOCHS = 1000
    LEARNING_RATE = 1e-4  # 降低学习率
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 训练配置 - 更新为使用64通道
    training_config = {
        "data_dir": DATA_DIR,
        "batch_size": BATCH_SIZE,
        "epochs": EPOCHS,
        "learning_rate": LEARNING_RATE,
        "device": str(DEVICE),
        "model": "Improved_ThreeDUNet128",
        "input_channels": 3,
        "base_channels": 64,  # 更新为64通道
        "diffusion_steps": 1000,
        "color_mode": "RGB",
        "improvements": ["64_channels_baseline", "conservative_augmentation", "linear_schedule", "stable_training"]
    }

    print(f"使用设备: {DEVICE}")
    print(f"所有文件将保存到: {SAVE_DIR}")

    # 创建数据集 - 使用保守的数据增强或完全禁用
    dataset = ThreeDBlockDataset(DATA_DIR, convert_to_grayscale=False, augment=False)  # 先禁用增强进行测试
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=2, pin_memory=True)

    print(f"数据集大小: {len(dataset)}")

    # 检查数据形状
    sample = dataset[0]
    print(f"数据形状: {sample.shape}")

    # 根据数据自动确定输入通道数
    in_channels = sample.shape[0]
    training_config["input_channels"] = in_channels
    print(f"自动检测到输入通道数: {in_channels}")

    # 初始化模型和训练器 - 使用64通道作为基线
    model = ThreeDUNet128Ablation(in_channels=in_channels, base_channels=64)  # 修改：使用64通道
    trainer = Diffusion3DTrainer128(model, DEVICE, T=1000)

    optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=10, verbose=True)

    # 训练状态初始化
    start_epoch = 1
    train_losses = []
    best_loss = float('inf')

    # 如果提供了检查点，则恢复训练
    if resume_from_checkpoint:
        start_epoch, train_losses, best_loss = load_checkpoint(
            model, optimizer, scheduler, resume_from_checkpoint)
        if start_epoch is None:
            print("无法加载检查点，从头开始训练")
            start_epoch = 1
        else:
            start_epoch += 1

    # 训练循环
    for epoch in range(start_epoch, EPOCHS + 1):
        try:
            avg_loss = trainer.train_epoch(dataloader, optimizer, epoch)
            scheduler.step(avg_loss)

            train_losses.append(avg_loss)
            current_lr = optimizer.param_groups[0]['lr']
            print(f"Epoch {epoch}/{EPOCHS}, 平均损失: {avg_loss:.6f}, 学习率: {current_lr:.8f}")

            # 保存最佳模型
            if avg_loss < best_loss:
                best_loss = avg_loss
                save_checkpoint(
                    epoch, model, optimizer, scheduler, train_losses, best_loss,
                    "improved_3d_diffusion_128_best_model.pth"
                )

            # 每10个epoch保存一次检查点
            if epoch % 10 == 0:
                save_checkpoint(
                    epoch, model, optimizer, scheduler, train_losses, best_loss,
                    f"improved_3d_diffusion_128_checkpoint_epoch_{epoch}.pth"
                )
                save_training_log(train_losses, training_config)

            # 每20个epoch生成一次样本
            if epoch % 20 == 0:
                try:
                    with torch.no_grad():
                        samples = trainer.sample((in_channels, 128, 128, 128), num_samples=1)
                        sample_volume = samples[0].cpu().numpy()

                        # 反归一化
                        sample_volume_uint8 = (sample_volume * 255).clip(0, 255).astype(np.uint8)

                        # 可视化样本切片
                        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
                        depths = [32, 64, 96]
                        for i, depth in enumerate(depths):
                            if in_channels == 1:
                                axes[i].imshow(sample_volume_uint8[0, depth], cmap='gray')
                            elif in_channels == 3:
                                rgb_slice = np.transpose(sample_volume_uint8[:, depth], (1, 2, 0))
                                axes[i].imshow(rgb_slice)
                            else:
                                axes[i].imshow(sample_volume_uint8[0, depth], cmap='gray')

                            axes[i].set_title(f"Sample Depth: {depth}")
                            axes[i].axis('off')

                        plt.suptitle(f"Epoch {epoch} - Generated 128×128×128 Sample (64 channels)")
                        plt.savefig(
                            os.path.join(VISUALIZATION_DIR, f"improved_generated_128_sample_epoch_{epoch}.png"),
                            bbox_inches='tight', dpi=150
                        )
                        plt.close()

                        # 保存生成的样本数据
                        sample_save_path = os.path.join(VISUALIZATION_DIR,
                                                        f"improved_generated_sample_epoch_{epoch}.npz")
                        np.savez_compressed(sample_save_path, volume=sample_volume_uint8)
                        print(f"生成样本已保存: {sample_save_path}")

                except Exception as e:
                    print(f"生成样本时出错: {e}")

            # 清理内存
            torch.cuda.empty_cache()

        except Exception as e:
            print(f"Epoch {epoch} 训练出错: {e}")
            torch.cuda.empty_cache()
            continue

    # 最终保存
    save_checkpoint(
        EPOCHS, model, optimizer, scheduler, train_losses, best_loss,
        "improved_3d_diffusion_128_final_model.pth"
    )
    save_training_log(train_losses, training_config)

    print(f"训练完成！所有文件已保存到: {SAVE_DIR}")


def run_ablation_experiment(experiment_name, config, save_dir=None):
    """运行单个消融实验"""

    # 创建实验特定的保存目录
    if save_dir is None:
        exp_dir = os.path.join(SAVE_DIR, f"ablation_{experiment_name}")
    else:
        exp_dir = os.path.join(save_dir, f"ablation_{experiment_name}")

    checkpoint_dir = os.path.join(exp_dir, "checkpoints")
    visualization_dir = os.path.join(exp_dir, "visualizations")
    log_dir = os.path.join(exp_dir, "logs")

    os.makedirs(exp_dir, exist_ok=True)
    os.makedirs(checkpoint_dir, exist_ok=True)
    os.makedirs(visualization_dir, exist_ok=True)
    os.makedirs(log_dir, exist_ok=True)

    print(f"\n{'='*60}")
    print(f"开始消融实验: {experiment_name}")
    print(f"配置: {config['description']}")
    print(f"保存目录: {exp_dir}")
    print(f"{'='*60}")

    # 训练参数
    DATA_DIR = "/mnt/128_high_quality"
    BATCH_SIZE = 1
    EPOCHS = 200  # 消融实验可以使用更少的epochs
    LEARNING_RATE = 1e-4
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 创建数据集
    dataset = ThreeDBlockDataset(
        DATA_DIR,
        convert_to_grayscale=False,
        augment=config.get("use_data_augmentation", False)
    )
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=2, pin_memory=True)

    # 获取输入通道数
    sample = dataset[0]
    in_channels = sample.shape[0]

    # 初始化模型
    model_config = {
        "use_time_embedding": config.get("use_time_embedding", True),
        "use_residual_blocks": config.get("use_residual_blocks", True),
        "use_attention": config.get("use_attention", False),
        "use_group_norm": config.get("use_group_norm", True)
    }

    model = ThreeDUNet128Ablation(
        in_channels=in_channels,
        base_channels=config.get("base_channels", 64),  # 默认使用64通道
        time_emb_dim=128,
        config=model_config
    )

    # 初始化训练器
    trainer = Diffusion3DTrainer128Ablation(
        model,
        DEVICE,
        T=config.get("num_diffusion_steps", 1000),
        noise_schedule=config.get("noise_schedule", "linear")
    )

    # 优化器
    optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=10, verbose=True
    )

    # 训练循环
    train_losses = []
    best_loss = float('inf')

    for epoch in range(1, EPOCHS + 1):
        try:
            avg_loss = trainer.train_epoch(dataloader, optimizer, epoch)
            scheduler.step(avg_loss)

            train_losses.append(avg_loss)
            current_lr = optimizer.param_groups[0]['lr']

            print(f"Epoch {epoch}/{EPOCHS}, 损失: {avg_loss:.6f}, 学习率: {current_lr:.8f}")

            # 保存最佳模型
            if avg_loss < best_loss:
                best_loss = avg_loss
                checkpoint = {
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'scheduler_state_dict': scheduler.state_dict(),
                    'train_losses': train_losses,
                    'best_loss': best_loss,
                    'config': config
                }
                torch.save(checkpoint, os.path.join(checkpoint_dir, f"best_model.pth"))

            # 每10个epoch保存检查点
            if epoch % 10 == 0:
                torch.save(checkpoint, os.path.join(checkpoint_dir, f"checkpoint_epoch_{epoch}.pth"))

                # 保存训练日志
                log_data = {
                    'experiment_name': experiment_name,
                    'config': config,
                    'train_losses': train_losses,
                    'best_loss': best_loss,
                    'epoch': epoch
                }
                with open(os.path.join(log_dir, f'training_log_epoch_{epoch}.json'), 'w') as f:
                    json.dump(log_data, f, indent=2)

            # 每20个epoch生成样本
            if epoch % 20 == 0:
                try:
                    with torch.no_grad():
                        samples = trainer.sample((in_channels, 128, 128, 128), num_samples=1)
                        sample_volume = samples[0].cpu().numpy()
                        sample_volume_uint8 = (sample_volume * 255).clip(0, 255).astype(np.uint8)

                        # 可视化
                        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
                        depths = [32, 64, 96]
                        for i, depth in enumerate(depths):
                            if in_channels == 1:
                                axes[i].imshow(sample_volume_uint8[0, depth], cmap='gray')
                            elif in_channels == 3:
                                rgb_slice = np.transpose(sample_volume_uint8[:, depth], (1, 2, 0))
                                axes[i].imshow(rgb_slice)
                            axes[i].set_title(f"Depth: {depth}")
                            axes[i].axis('off')

                        plt.suptitle(f"{experiment_name} - Epoch {epoch}")
                        plt.savefig(os.path.join(visualization_dir, f"sample_epoch_{epoch}.png"),
                                   bbox_inches='tight', dpi=150)
                        plt.close()

                except Exception as e:
                    print(f"生成样本时出错: {e}")

            torch.cuda.empty_cache()

        except Exception as e:
            print(f"Epoch {epoch} 训练出错: {e}")
            continue

    # 保存最终模型和结果
    final_checkpoint = {
        'epoch': EPOCHS,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict(),
        'train_losses': train_losses,
        'best_loss': best_loss,
        'config': config
    }
    torch.save(final_checkpoint, os.path.join(checkpoint_dir, "final_model.pth"))

    # 绘制损失曲线
    plt.figure(figsize=(10, 6))
    plt.plot(train_losses)
    plt.title(f'{experiment_name} - Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.grid(True)
    plt.savefig(os.path.join(visualization_dir, 'training_loss.png'), bbox_inches='tight', dpi=150)
    plt.close()

    # 保存实验结果摘要
    results_summary = {
        'experiment_name': experiment_name,
        'config': config,
        'final_loss': train_losses[-1] if train_losses else None,
        'best_loss': best_loss,
        'total_epochs': EPOCHS,
        'train_loss_history': train_losses
    }

    with open(os.path.join(log_dir, 'results_summary.json'), 'w') as f:
        json.dump(results_summary, f, indent=2)

    print(f"\n消融实验 {experiment_name} 完成!")
    print(f"最佳损失: {best_loss:.6f}")
    print(f"最终损失: {train_losses[-1] if train_losses else 'N/A':.6f}")

    return results_summary


def run_all_ablation_experiments():
    """运行所有消融实验"""

    ablation_config = AblationConfig()
    all_results = {}

    # 创建消融实验总目录
    ablation_dir = os.path.join(SAVE_DIR, "ablation_studies")
    os.makedirs(ablation_dir, exist_ok=True)

    print(f"开始运行消融实验，结果将保存到: {ablation_dir}")

    # 按顺序运行所有实验
    for exp_name, config in ablation_config.experiments.items():
        try:
            results = run_ablation_experiment(exp_name, config, ablation_dir)
            all_results[exp_name] = {
                'best_loss': results['best_loss'],
                'final_loss': results['final_loss'],
                'description': config['description']
            }

            # 保存中间结果
            with open(os.path.join(ablation_dir, 'all_results_intermediate.json'), 'w') as f:
                json.dump(all_results, f, indent=2)

        except Exception as e:
            print(f"实验 {exp_name} 失败: {e}")
            all_results[exp_name] = {'error': str(e)}
            continue

    # 比较所有实验结果
    print("\n" + "="*80)
    print("消融实验结果汇总")
    print("="*80)

    results_table = []
    for exp_name, result in all_results.items():
        if 'error' not in result:
            results_table.append({
                '实验': exp_name,
                '描述': result.get('description', ''),
                '最佳损失': f"{result.get('best_loss', float('inf')):.6f}",
                '最终损失': f"{result.get('final_loss', float('inf')):.6f}"
            })

    # 按最佳损失排序
    results_table.sort(key=lambda x: float(x['最佳损失']))

    # 打印表格
    print("\n排名\t实验名称\t\t最佳损失\t最终损失\t描述")
    print("-"*100)
    for i, row in enumerate(results_table, 1):
        print(f"{i:2d}\t{row['实验']:20s}\t{row['最佳损失']:10s}\t{row['最终损失']:10s}\t{row['描述']}")

    # 可视化比较
    plt.figure(figsize=(14, 8))

    # 1. 损失比较图
    plt.subplot(2, 1, 1)
    experiment_names = []
    best_losses = []

    for exp_name, result in all_results.items():
        if 'error' not in result and result.get('best_loss') is not None:
            experiment_names.append(exp_name)
            best_losses.append(result['best_loss'])

    bars = plt.bar(experiment_names, best_losses)
    plt.title('各消融实验最佳损失比较')
    plt.ylabel('损失')
    plt.xticks(rotation=45, ha='right')

    # 为最小值添加标注
    if best_losses:
        min_idx = np.argmin(best_losses)
        bars[min_idx].set_color('green')
        plt.annotate('最佳', xy=(min_idx, best_losses[min_idx]),
                    xytext=(0, 10), textcoords='offset points',
                    ha='center', color='green', fontweight='bold')

    # 2. 损失趋势比较（需要加载各个实验的训练历史）
    plt.subplot(2, 1, 2)

    for exp_name, result in all_results.items():
        if 'error' not in result:
            # 尝试加载训练历史
            exp_dir = os.path.join(ablation_dir, f"ablation_{exp_name}")
            log_dir = os.path.join(exp_dir, "logs")
            summary_path = os.path.join(log_dir, "results_summary.json")

            if os.path.exists(summary_path):
                with open(summary_path, 'r') as f:
                    exp_data = json.load(f)
                    if 'train_loss_history' in exp_data:
                        plt.plot(exp_data['train_loss_history'], label=exp_name)

    plt.title('各实验训练损失趋势')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.grid(True)

    plt.tight_layout()
    plt.savefig(os.path.join(ablation_dir, 'ablation_comparison.png'),
               bbox_inches='tight', dpi=150)
    plt.close()

    # 保存最终结果
    with open(os.path.join(ablation_dir, 'ablation_results_final.json'), 'w') as f:
        json.dump({
            'experiments': all_results,
            'ranking': results_table,
            'summary': {
                'best_experiment': results_table[0]['实验'] if results_table else None,
                'best_loss': results_table[0]['最佳损失'] if results_table else None,
                'total_experiments': len(all_results),
                'successful_experiments': len(results_table)
            }
        }, f, indent=2)

    print(f"\n消融实验完成！所有结果已保存到: {ablation_dir}")
    print(f"最佳配置: {results_table[0]['实验'] if results_table else '无'} "
          f"(损失: {results_table[0]['最佳损失'] if results_table else 'N/A'})")

    return all_results


def analyze_ablation_results(results_dir=None):
    """分析消融实验结果"""
    if results_dir is None:
        results_dir = os.path.join(SAVE_DIR, "ablation_studies")

    if not os.path.exists(results_dir):
        print(f"结果目录不存在: {results_dir}")
        return

    # 加载最终结果
    results_file = os.path.join(results_dir, "ablation_results_final.json")
    if os.path.exists(results_file):
        with open(results_file, 'r') as f:
            results = json.load(f)

        # 生成详细分析报告
        analysis_report = {
            "analysis_date": str(datetime.now()),
            "total_experiments": results.get('summary', {}).get('total_experiments', 0),
            "best_experiment": results.get('summary', {}).get('best_experiment'),
            "best_loss": results.get('summary', {}).get('best_loss'),
            "detailed_comparison": []
        }

        # 分析各个组件的影响
        if 'ranking' in results:
            for i, exp in enumerate(results['ranking']):
                analysis_report['detailed_comparison'].append({
                    "rank": i + 1,
                    "experiment": exp['实验'],
                    "description": exp['描述'],
                    "best_loss": exp['最佳损失'],
                    "relative_to_best": f"{(float(exp['最佳损失']) / float(results['ranking'][0]['最佳损失']) - 1) * 100:.1f}%"
                })

        # 保存分析报告
        report_file = os.path.join(results_dir, "analysis_report.json")
        with open(report_file, 'w') as f:
            json.dump(analysis_report, f, indent=2)

        print(f"分析报告已保存: {report_file}")

        # 打印关键发现
        print("\n关键发现:")
        print("-" * 50)
        for i, comp in enumerate(analysis_report['detailed_comparison'][:3], 1):
            print(f"{i}. {comp['experiment']}: {comp['best_loss']} ({comp['relative_to_best']} vs best)")

        return analysis_report
    else:
        print("未找到结果文件，请先运行消融实验")
        return None


if __name__ == "__main__":
    print("3D扩散模型训练与消融实验")

    # 选择要运行的模式
    print("\n请选择运行模式:")
    print("1. 运行完整的消融实验（所有配置）")
    print("2. 运行单个实验")
    print("3. 只运行基线模型（64通道）")
    print("4. 分析已有的消融实验结果")

    choice = input("请输入选择 (1-4): ").strip()

    if choice == "1":
        # 运行所有消融实验
        results = run_all_ablation_experiments()
    elif choice == "2":
        # 运行单个实验
        ablation_config = AblationConfig()
        print("\n可用的实验配置:")
        for i, (exp_name, config) in enumerate(ablation_config.experiments.items(), 1):
            print(f"{i}. {exp_name}: {config['description']}")

        exp_idx = int(input("\n请输入实验编号: ")) - 1
        exp_names = list(ablation_config.experiments.keys())

        if 0 <= exp_idx < len(exp_names):
            exp_name = exp_names[exp_idx]
            config = ablation_config.experiments[exp_name]
            run_ablation_experiment(exp_name, config)
        else:
            print("无效的选择!")
    elif choice == "3":
        # 只运行基线模型（64通道）
        ablation_config = AblationConfig()
        baseline_config = ablation_config.experiments["baseline"]
        run_ablation_experiment("baseline", baseline_config)
    elif choice == "4":
        # 分析结果
        analyze_ablation_results()
    else:
        print("无效的选择!")