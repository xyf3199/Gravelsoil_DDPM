import os
import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm
import matplotlib.pyplot as plt
import cv2
from PIL import Image
import json

# ============== 定义保存路径 ==============
INPUT_DIR = "/mnt/PyCharm_Project_4/128-512"  # 512×512×512 NPZ文件目录
OUTPUT_DIR = "/mnt/PyCharm_Project_4/22"  # 彩色切片输出目录
SLICE_VISUALIZATION_DIR = os.path.join(OUTPUT_DIR, "visualizations")  # 切片可视化目录

# 创建所有必要的目录
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(SLICE_VISUALIZATION_DIR, exist_ok=True)


class ColorVolumeSlicer:
    """彩色3D体积切片器 - 专门生成512张512×512彩色切片"""

    def __init__(self):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"使用设备: {self.device}")

    def load_volume(self, file_path):
        """加载NPZ文件中的体积数据"""
        data = np.load(file_path)
        if 'volume' in data:
            volume = data['volume']
        else:
            # 尝试找到包含体积数据的键
            for key in data.keys():
                if data[key].ndim >= 3:  # 寻找3D或4D数组
                    volume = data[key]
                    break
            else:
                raise ValueError(f"在文件 {file_path} 中找不到体积数据")

        print(f"加载体积: {volume.shape}, 数据类型: {volume.dtype}, 值范围: [{volume.min():.3f}, {volume.max():.3f}]")
        return volume

    def ensure_color_volume(self, volume):
        """确保体积是彩色格式 (512, 512, 512, 3)"""
        print("处理体积格式...")

        # 处理不同的输入格式
        if volume.ndim == 4:
            if volume.shape[0] == 3:  # (3, 512, 512, 512) - 通道在前
                print("检测到通道在前格式 (C, D, H, W)，转换为 (D, H, W, C)")
                volume = np.transpose(volume, (1, 2, 3, 0))
            elif volume.shape[-1] == 3:  # (512, 512, 512, 3) - 通道在后
                print("检测到通道在后格式 (D, H, W, C)，保持原格式")
            else:
                print(f"未知的4D格式 {volume.shape}，尝试处理为灰度")
                if volume.shape[0] == 1:  # 单通道在前
                    volume = np.transpose(volume, (1, 2, 3, 0))
                    volume = np.repeat(volume, 3, axis=-1)  # 转换为RGB
                elif volume.shape[-1] == 1:  # 单通道在后
                    volume = np.repeat(volume, 3, axis=-1)  # 转换为RGB
        elif volume.ndim == 3:  # (512, 512, 512) - 灰度
            print("检测到3D灰度体积，转换为彩色")
            volume = np.stack([volume] * 3, axis=-1)  # 转换为RGB

        # 确保尺寸正确
        if volume.shape[:3] != (512, 512, 512):
            print(f"调整体积尺寸从 {volume.shape} 到 (512, 512, 512, 3)")
            from scipy.ndimage import zoom
            zoom_factors = (
                512 / volume.shape[0],
                512 / volume.shape[1],
                512 / volume.shape[2],
                1  # 保持通道数不变
            )
            volume = zoom(volume, zoom_factors, order=1)

        print(f"最终体积形状: {volume.shape}")
        return volume

    def normalize_to_uint8(self, volume):
        """将体积数据归一化到0-255范围并转换为uint8"""
        if volume.dtype == np.uint8:
            return volume

        # 线性归一化到0-1
        v_min = volume.min()
        v_max = volume.max()
        print(f"归一化: 原始范围 [{v_min:.3f}, {v_max:.3f}]")

        if v_max - v_min > 0:
            normalized = (volume - v_min) / (v_max - v_min)
        else:
            normalized = np.zeros_like(volume, dtype=np.float32)

        # 转换为0-255
        volume_uint8 = (normalized * 255).clip(0, 255).astype(np.uint8)
        print(f"归一化完成: 输出范围 [{volume_uint8.min()}, {volume_uint8.max()}]")

        return volume_uint8

    def extract_all_depth_slices(self, volume):
        """提取所有深度方向的512张切片"""
        print("提取深度方向切片...")
        slices = []

        for depth in range(512):
            slice_data = volume[depth, :, :, :]  # 提取深度切片 (512, 512, 3)
            slices.append(slice_data)

        print(f"共提取 {len(slices)} 张切片")
        return slices

    def save_color_slice(self, slice_data, file_path, format='png', quality=95):
        """保存彩色切片为图像文件"""
        # 确保是RGB格式
        if slice_data.shape[-1] == 4:  # RGBA转RGB
            slice_data = slice_data[:, :, :3]
        elif slice_data.shape[-1] == 1:  # 灰度转RGB
            slice_data = np.repeat(slice_data, 3, axis=-1)

        # 确保数据类型正确
        if slice_data.dtype != np.uint8:
            slice_data = slice_data.astype(np.uint8)

        # 使用PIL保存，确保颜色正确
        if format.lower() == 'png':
            Image.fromarray(slice_data, mode='RGB').save(file_path, format='PNG')
        elif format.lower() == 'jpg':
            Image.fromarray(slice_data, mode='RGB').save(file_path, format='JPEG', quality=quality)
        else:
            # 使用OpenCV作为备选
            cv2.imwrite(file_path, cv2.cvtColor(slice_data, cv2.COLOR_RGB2BGR))

    def create_slice_grid_preview(self, slices, volume_name, output_dir, grid_size=8):
        """创建切片网格预览图"""
        print("创建切片预览图...")

        # 选择要显示的切片
        total_slices = len(slices)
        step = max(1, total_slices // (grid_size * grid_size))
        display_indices = list(range(0, total_slices, step))[:grid_size * grid_size]
        display_slices = [slices[i] for i in display_indices]

        fig, axes = plt.subplots(grid_size, grid_size, figsize=(20, 20))

        # 如果只有一行，确保axes是二维数组
        if grid_size == 1:
            axes = np.array([axes])
        if not isinstance(axes, np.ndarray):
            axes = np.array(axes)

        # 绘制每个切片
        for i, (slice_data, idx) in enumerate(zip(display_slices, display_indices)):
            row = i // grid_size
            col = i % grid_size

            axes[row, col].imshow(slice_data)
            axes[row, col].set_title(f"切片 {idx}", fontsize=8)
            axes[row, col].axis('off')

        plt.suptitle(f"{volume_name} - 彩色切片预览 (共{total_slices}张切片)", fontsize=16)
        plt.tight_layout()

        # 保存预览图
        preview_path = os.path.join(output_dir, f"{volume_name}_color_slices_preview.png")
        plt.savefig(preview_path, bbox_inches='tight', dpi=150)
        plt.close()

        print(f"切片预览已保存: {preview_path}")
        return preview_path

    def process_single_volume(self, input_path, output_dir, image_format='png', create_preview=True):
        """处理单个体积文件，生成512张彩色切片"""
        volume_name = os.path.splitext(os.path.basename(input_path))[0]
        slices_output_dir = os.path.join(output_dir, volume_name, "color_slices")
        os.makedirs(slices_output_dir, exist_ok=True)

        print(f"处理体积: {volume_name}")
        print("=" * 50)

        try:
            # 1. 加载体积
            volume = self.load_volume(input_path)

            # 2. 确保是彩色格式
            color_volume = self.ensure_color_volume(volume)

            # 3. 归一化到0-255
            normalized_volume = self.normalize_to_uint8(color_volume)

            # 4. 提取所有深度切片
            slices = self.extract_all_depth_slices(normalized_volume)

            # 5. 保存所有切片
            print("保存彩色切片...")
            slice_files = []

            for depth in tqdm(range(len(slices)), desc="保存切片"):
                slice_filename = f"color_slice_{depth:04d}.{image_format}"
                slice_path = os.path.join(slices_output_dir, slice_filename)

                self.save_color_slice(slices[depth], slice_path, format=image_format)
                slice_files.append(slice_filename)

            print(f"保存完成: {len(slice_files)} 张彩色切片")

            # 6. 创建预览图
            if create_preview:
                self.create_slice_grid_preview(slices, volume_name, SLICE_VISUALIZATION_DIR)

            # 7. 保存切片信息
            info_path = os.path.join(output_dir, volume_name, "slices_info.json")
            with open(info_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'volume_name': volume_name,
                    'original_shape': volume.shape,
                    'processed_shape': normalized_volume.shape,
                    'data_type': str(volume.dtype),
                    'slice_count': len(slices),
                    'slice_size': '512×512',
                    'slice_format': 'RGB彩色',
                    'slice_files': slice_files,
                    'output_directory': slices_output_dir
                }, f, indent=2, ensure_ascii=False)

            print(f"切片信息已保存: {info_path}")
            return len(slices)

        except Exception as e:
            print(f"处理体积 {volume_name} 时出错: {e}")
            return 0

    def process_directory(self, input_dir, output_dir, image_format='png', create_preview=True):
        """处理目录中的所有NPZ文件"""
        # 查找所有NPZ文件
        npz_files = [f for f in os.listdir(input_dir) if f.endswith('.npz')]
        print(f"在目录 {input_dir} 中找到 {len(npz_files)} 个NPZ文件")

        if len(npz_files) == 0:
            print("未找到NPZ文件")
            return

        total_slices = 0
        processed_files = []

        # 处理每个文件
        for filename in tqdm(npz_files, desc="处理体积文件"):
            input_path = os.path.join(input_dir, filename)

            slice_count = self.process_single_volume(
                input_path, output_dir, image_format, create_preview
            )

            if slice_count > 0:
                total_slices += slice_count
                processed_files.append(filename)

            print()  # 空行分隔

        # 保存总体信息
        summary_path = os.path.join(output_dir, "color_slices_summary.json")
        with open(summary_path, 'w', encoding='utf-8') as f:
            json.dump({
                'input_directory': input_dir,
                'output_directory': output_dir,
                'total_volumes_processed': len(processed_files),
                'total_slices_generated': total_slices,
                'slice_format': '512×512 RGB彩色',
                'image_format': image_format,
                'processed_files': processed_files,
                'timestamp': str(np.datetime64('now'))
            }, f, indent=2, ensure_ascii=False)

        print("=" * 60)
        print("处理完成!")
        print(f"共处理 {len(processed_files)} 个体积文件")
        print(f"共生成 {total_slices} 张512×512彩色切片")
        print(f"所有切片保存在: {output_dir}")
        print(f"处理汇总: {summary_path}")


def main():
    """主函数"""
    print("彩色3D体积切片工具 - 生成512张512×512彩色切片")
    print("=" * 60)

    # 检查输入目录
    if not os.path.exists(INPUT_DIR):
        print(f"错误: 输入目录不存在: {INPUT_DIR}")
        print("请确保512体积文件已生成并保存在正确位置")
        return

    # 初始化彩色切片器
    slicer = ColorVolumeSlicer()

    # 处理目录
    slicer.process_directory(
        input_dir=INPUT_DIR,
        output_dir=OUTPUT_DIR,
        image_format='png',  # 输出格式
        create_preview=True  # 创建预览图
    )

    print("彩色切片生成完成！")


if __name__ == "__main__":
    main()