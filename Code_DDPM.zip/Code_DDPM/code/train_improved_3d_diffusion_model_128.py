import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import matplotlib.pyplot as plt
import json

# ============== 定义保存路径 ==============
SAVE_DIR = "/mnt/PyCharm_Project_4/improved_3d_training1"
CHECKPOINT_DIR = os.path.join(SAVE_DIR, "checkpoints")
VISUALIZATION_DIR = os.path.join(SAVE_DIR, "visualizations")
LOG_DIR = os.path.join(SAVE_DIR, "logs")

# 创建所有必要的目录
os.makedirs(SAVE_DIR, exist_ok=True)
os.makedirs(CHECKPOINT_DIR, exist_ok=True)
os.makedirs(VISUALIZATION_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)


class ThreeDBlockDataset(Dataset):
    """改进的3D块数据集 - 更保守的数据增强策略"""

    def __init__(self, data_dir, transform=None, convert_to_grayscale=False, augment=False):
        self.data_dir = data_dir
        self.transform = transform
        self.convert_to_grayscale = convert_to_grayscale
        self.augment = augment
        self.block_files = [f for f in os.listdir(data_dir) if f.endswith('.npz')]
        print(f"找到 {len(self.block_files)} 个数据文件")

    def __len__(self):
        return len(self.block_files)

    def __getitem__(self, idx):
        try:
            # 加载数据
            data = np.load(os.path.join(self.data_dir, self.block_files[idx]))
            volume = data['volume'].astype(np.float32) / 255.0
            volume = volume.copy()  # 确保内存连续

            # 确保尺寸为128×128×128
            if volume.shape[:3] != (128, 128, 128):
                volume = self._resize_volume(volume, target_size=128)

            # 更保守的数据增强 - 只在训练时使用，且概率更低
            if self.augment:
                volume = self._conservative_augment_volume(volume)

            # 转换为灰度图（如果需要）
            if self.convert_to_grayscale and volume.shape[-1] > 1:
                volume = self._to_grayscale(volume)

            # 转换为PyTorch tensor (C, D, H, W)
            volume_tensor = torch.from_numpy(volume).permute(3, 0, 1, 2)

            if self.transform:
                volume_tensor = self.transform(volume_tensor)

            return volume_tensor

        except Exception as e:
            print(f"加载文件 {self.block_files[idx]} 时出错: {e}")
            return self.__getitem__((idx + 1) % len(self.block_files))

    def _resize_volume(self, volume, target_size=128):
        """调整体积到目标尺寸"""
        from scipy.ndimage import zoom
        depth, height, width, channels = volume.shape
        zoom_factors = (
            target_size / depth,
            target_size / height,
            target_size / width,
            1
        )
        resized_volume = zoom(volume, zoom_factors, order=1)
        return resized_volume.astype(np.float32).copy()

    def _to_grayscale(self, volume):
        """将多通道体积转换为单通道灰度图"""
        if volume.shape[-1] == 3:
            gray = np.dot(volume[..., :3], [0.2989, 0.5870, 0.1140])
        elif volume.shape[-1] == 4:
            gray = np.dot(volume[..., :3], [0.2989, 0.5870, 0.1140])
        else:
            gray = np.mean(volume, axis=-1)
        gray = gray[..., np.newaxis]
        return gray.astype(np.float32).copy()

    def _conservative_augment_volume(self, volume):
        """保守的数据增强策略 - 保持原始特征"""
        augmented = volume.copy()

        # 只进行轻微的增强，避免破坏3D结构
        # 1. 小角度旋转 (只使用0°和180°，避免90°和270°破坏结构)
        if np.random.random() > 0.7:  # 30%概率
            k = np.random.choice([0, 2])  # 只选择0°或180°旋转
            augmented = np.rot90(augmented, k, axes=(1, 2))

        # 2. 只在水平方向翻转 (避免垂直翻转破坏空间关系)
        if np.random.random() > 0.7:  # 30%概率
            augmented = np.flip(augmented, axis=2)  # 只翻转宽度维度

        # 3. 轻微的亮度调整
        if np.random.random() > 0.8:  # 20%概率
            brightness_factor = np.random.uniform(0.9, 1.1)
            augmented = np.clip(augmented * brightness_factor, 0, 1)

        return augmented


class TimeEmbedding(nn.Module):
    """时间步嵌入"""

    def __init__(self, dim):
        super().__init__()
        self.dim = dim
        self.proj = nn.Sequential(
            nn.Linear(dim, dim * 2),
            nn.SiLU(),
            nn.Linear(dim * 2, dim)
        )

    def forward(self, timesteps):
        half_dim = self.dim // 2
        emb = torch.log(torch.tensor(10000.0)) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, device=timesteps.device) * -emb)
        emb = timesteps[:, None] * emb[None, :]
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=-1)
        return self.proj(emb)


class ResidualBlock3D(nn.Module):
    """3D残差块"""

    def __init__(self, in_channels, out_channels, time_emb_dim=None):
        super().__init__()
        self.time_emb_dim = time_emb_dim

        self.conv1 = nn.Conv3d(in_channels, out_channels, 3, padding=1)
        self.norm1 = nn.GroupNorm(8, out_channels)
        self.conv2 = nn.Conv3d(out_channels, out_channels, 3, padding=1)
        self.norm2 = nn.GroupNorm(8, out_channels)

        if in_channels != out_channels:
            self.shortcut = nn.Conv3d(in_channels, out_channels, 1)
        else:
            self.shortcut = nn.Identity()

        if time_emb_dim is not None:
            self.time_emb_proj = nn.Linear(time_emb_dim, out_channels)

        self.activation = nn.SiLU()

    def forward(self, x, t_emb=None):
        residual = self.shortcut(x)

        x = self.conv1(x)
        x = self.norm1(x)

        if t_emb is not None and self.time_emb_dim is not None:
            t_emb = self.time_emb_proj(self.activation(t_emb))
            t_emb = t_emb.view(t_emb.shape[0], t_emb.shape[1], 1, 1, 1)
            x = x + t_emb

        x = self.activation(x)
        x = self.conv2(x)
        x = self.norm2(x)

        return self.activation(x + residual)


class ThreeDUNet128(nn.Module):
    """改进的3D U-Net - 修复特征对齐问题"""

    def __init__(self, in_channels=3, base_channels=64, time_emb_dim=128):
        super(ThreeDUNet128, self).__init__()

        # 时间步嵌入
        self.time_emb_dim = time_emb_dim
        self.time_embed = TimeEmbedding(time_emb_dim)

        # 编码器
        self.enc1 = ResidualBlock3D(in_channels, base_channels, time_emb_dim)
        self.enc2 = ResidualBlock3D(base_channels, base_channels * 2, time_emb_dim)
        self.enc3 = ResidualBlock3D(base_channels * 2, base_channels * 4, time_emb_dim)
        self.enc4 = ResidualBlock3D(base_channels * 4, base_channels * 8, time_emb_dim)

        # 中间层
        self.mid1 = ResidualBlock3D(base_channels * 8, base_channels * 8, time_emb_dim)
        self.mid2 = ResidualBlock3D(base_channels * 8, base_channels * 8, time_emb_dim)

        # 解码器 - 修正通道数匹配
        self.dec4 = ResidualBlock3D(base_channels * 8 + base_channels * 4, base_channels * 4, time_emb_dim)
        self.dec3 = ResidualBlock3D(base_channels * 4 + base_channels * 2, base_channels * 2, time_emb_dim)
        self.dec2 = ResidualBlock3D(base_channels * 2 + base_channels, base_channels, time_emb_dim)
        self.dec1 = ResidualBlock3D(base_channels, base_channels, time_emb_dim)

        self.final_conv = nn.Conv3d(base_channels, in_channels, kernel_size=1)

        self.downsample = nn.MaxPool3d(2)
        self.upsample = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=True)

    def forward(self, x, timesteps):
        # 时间步嵌入
        t_emb = self.time_embed(timesteps)

        # 编码器
        e1 = self.enc1(x, t_emb)  # (B, 32, 128, 128, 128)
        e2 = self.enc2(self.downsample(e1), t_emb)  # (B, 64, 64, 64, 64)
        e3 = self.enc3(self.downsample(e2), t_emb)  # (B, 128, 32, 32, 32)
        e4 = self.enc4(self.downsample(e3), t_emb)  # (B, 256, 16, 16, 16)

        # 中间层
        m = self.mid1(e4, t_emb)
        m = self.mid2(m, t_emb)

        # 解码器 - 确保特征对齐
        d4 = self.upsample(m)  # (B, 256, 32, 32, 32)
        d4 = self.dec4(torch.cat([d4, e3], dim=1), t_emb)  # (B, 128, 32, 32, 32)

        d3 = self.upsample(d4)  # (B, 128, 64, 64, 64)
        d3 = self.dec3(torch.cat([d3, e2], dim=1), t_emb)  # (B, 64, 64, 64, 64)

        d2 = self.upsample(d3)  # (B, 64, 128, 128, 128)
        d2 = self.dec2(torch.cat([d2, e1], dim=1), t_emb)  # (B, 32, 128, 128, 128)

        d1 = self.dec1(d2, t_emb)  # (B, 32, 128, 128, 128)

        return self.final_conv(d1)


class Diffusion3DTrainer128:
    """改进的3D扩散模型训练器"""

    def __init__(self, model, device, T=1000, beta_start=1e-4, beta_end=0.02):
        self.model = model.to(device)
        self.device = device
        self.T = T

        # 线性噪声调度（更稳定）
        self.betas = torch.linspace(beta_start, beta_end, T).to(device)
        self.alphas = 1. - self.betas
        self.alphas_cumprod = torch.cumprod(self.alphas, dim=0)
        self.alphas_cumprod_prev = F.pad(self.alphas_cumprod[:-1], (1, 0), value=1.0)

        # 预计算系数
        self.sqrt_alphas_cumprod = torch.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(1. - self.alphas_cumprod)
        self.sqrt_recip_alphas = torch.sqrt(1.0 / self.alphas)
        self.posterior_variance = self.betas * (1. - self.alphas_cumprod_prev) / (1. - self.alphas_cumprod)

    def forward_diffusion(self, x0, t):
        """前向扩散过程"""
        noise = torch.randn_like(x0)
        sqrt_alphas_cumprod_t = self.sqrt_alphas_cumprod[t].view(-1, 1, 1, 1, 1)
        sqrt_one_minus_alphas_cumprod_t = self.sqrt_one_minus_alphas_cumprod[t].view(-1, 1, 1, 1, 1)
        xt = sqrt_alphas_cumprod_t * x0 + sqrt_one_minus_alphas_cumprod_t * noise
        return xt, noise

    def train_epoch(self, dataloader, optimizer, epoch):
        """训练一个epoch"""
        self.model.train()
        total_loss = 0
        num_batches = 0

        pbar = tqdm(dataloader, desc=f"Epoch {epoch}")
        for batch in pbar:
            try:
                x0 = batch.to(self.device)
                optimizer.zero_grad()

                # 随机采样时间步
                t = torch.randint(0, self.T, (x0.shape[0],), device=self.device)

                # 前向扩散
                xt, noise = self.forward_diffusion(x0, t)

                # 预测噪声
                predicted_noise = self.model(xt, t)

                # 计算损失
                loss = F.mse_loss(predicted_noise, noise)
                loss.backward()

                # 梯度裁剪
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                optimizer.step()

                total_loss += loss.item()
                num_batches += 1
                pbar.set_postfix({"Loss": f"{loss.item():.6f}"})

            except RuntimeError as e:
                if "out of memory" in str(e):
                    print("内存不足，跳过该批次")
                    torch.cuda.empty_cache()
                    continue
                else:
                    raise e

        return total_loss / num_batches if num_batches > 0 else float('inf')

    def sample(self, shape, num_samples=1):
        """采样生成新的3D块"""
        self.model.eval()
        with torch.no_grad():
            # 从纯噪声开始
            x = torch.randn((num_samples, *shape), device=self.device)

            for t in tqdm(range(self.T - 1, -1, -1), desc="Sampling"):
                t_batch = torch.full((num_samples,), t, device=self.device, dtype=torch.long)

                # 预测噪声
                predicted_noise = self.model(x, t_batch)

                # 计算系数
                alpha = self.alphas[t]
                alpha_cumprod = self.alphas_cumprod[t]
                alpha_cumprod_prev = self.alphas_cumprod_prev[t]
                beta = self.betas[t]

                # 计算均值和方差
                sqrt_recip_alpha = self.sqrt_recip_alphas[t]
                sqrt_one_minus_alpha_cumprod = self.sqrt_one_minus_alphas_cumprod[t]

                # 计算均值
                model_mean = sqrt_recip_alpha * (
                        x - beta * predicted_noise / sqrt_one_minus_alpha_cumprod
                )

                if t == 0:
                    x = model_mean
                else:
                    posterior_variance = self.posterior_variance[t]
                    noise = torch.randn_like(x)
                    x = model_mean + torch.sqrt(posterior_variance) * noise

                # 清理内存
                if t % 100 == 0:
                    torch.cuda.empty_cache()

            return x


def save_checkpoint(epoch, model, optimizer, scheduler, train_losses, best_loss, filename):
    """保存训练检查点"""
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict() if scheduler else None,
        'train_losses': train_losses,
        'best_loss': best_loss,
    }
    torch.save(checkpoint, os.path.join(CHECKPOINT_DIR, filename))
    print(f"检查点已保存: {filename}")


def load_checkpoint(model, optimizer, scheduler, filename):
    """加载训练检查点"""
    checkpoint_path = os.path.join(CHECKPOINT_DIR, filename)
    if not os.path.exists(checkpoint_path):
        print(f"检查点文件不存在: {checkpoint_path}")
        return None, None, None, None, None

    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    if scheduler and checkpoint['scheduler_state_dict']:
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])

    print(f"从检查点恢复训练: {filename}, 起始epoch: {checkpoint['epoch']}")
    return checkpoint['epoch'], checkpoint['train_losses'], checkpoint['best_loss']


def save_training_log(train_losses, config):
    """保存训练日志和配置"""
    # 保存损失历史
    loss_log_path = os.path.join(LOG_DIR, "training_losses.json")
    with open(loss_log_path, 'w') as f:
        json.dump(train_losses, f, indent=2)

    # 保存训练配置
    config_log_path = os.path.join(LOG_DIR, "training_config.json")
    with open(config_log_path, 'w') as f:
        json.dump(config, f, indent=2)

    # 绘制损失曲线
    plt.figure(figsize=(10, 6))
    plt.plot(train_losses)
    plt.title('Improved 128×128×128 3D Diffusion Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.grid(True)
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'improved_3d_diffusion_128_training_loss.png'),
                bbox_inches='tight', dpi=150)
    plt.close()


def train_improved_3d_diffusion_model_128(resume_from_checkpoint=None):
    """改进的128×128×128 3D扩散模型训练"""
    # 配置参数
    DATA_DIR = "/mnt/PyCharm_Project_4/6/3d_blocks_random/128_high_quality"
    BATCH_SIZE = 1  # 使用更小的批次确保稳定性
    EPOCHS = 1000
    LEARNING_RATE = 1e-4  # 降低学习率
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 训练配置
    training_config = {
        "data_dir": DATA_DIR,
        "batch_size": BATCH_SIZE,
        "epochs": EPOCHS,
        "learning_rate": LEARNING_RATE,
        "device": str(DEVICE),
        "model": "Improved_ThreeDUNet128",
        "input_channels": 3,
        "base_channels": 32,
        "diffusion_steps": 1000,
        "color_mode": "RGB",
        "improvements": ["conservative_augmentation", "linear_schedule", "stable_training"]
    }

    print(f"使用设备: {DEVICE}")
    print(f"所有文件将保存到: {SAVE_DIR}")

    # 创建数据集 - 使用保守的数据增强或完全禁用
    dataset = ThreeDBlockDataset(DATA_DIR, convert_to_grayscale=False, augment=False)  # 先禁用增强进行测试
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=2, pin_memory=True)

    print(f"数据集大小: {len(dataset)}")

    # 检查数据形状
    sample = dataset[0]
    print(f"数据形状: {sample.shape}")

    # 根据数据自动确定输入通道数
    in_channels = sample.shape[0]
    training_config["input_channels"] = in_channels
    print(f"自动检测到输入通道数: {in_channels}")

    # 初始化模型和训练器
    model = ThreeDUNet128(in_channels=in_channels, base_channels=64)
    trainer = Diffusion3DTrainer128(model, DEVICE, T=1000)

    optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=10, verbose=True)

    # 训练状态初始化
    start_epoch = 1
    train_losses = []
    best_loss = float('inf')

    # 如果提供了检查点，则恢复训练
    if resume_from_checkpoint:
        start_epoch, train_losses, best_loss = load_checkpoint(
            model, optimizer, scheduler, resume_from_checkpoint)
        if start_epoch is None:
            print("无法加载检查点，从头开始训练")
            start_epoch = 1
        else:
            start_epoch += 1

    # 训练循环
    for epoch in range(start_epoch, EPOCHS + 1):
        try:
            avg_loss = trainer.train_epoch(dataloader, optimizer, epoch)
            scheduler.step(avg_loss)

            train_losses.append(avg_loss)
            current_lr = optimizer.param_groups[0]['lr']
            print(f"Epoch {epoch}/{EPOCHS}, 平均损失: {avg_loss:.6f}, 学习率: {current_lr:.8f}")

            # 保存最佳模型
            if avg_loss < best_loss:
                best_loss = avg_loss
                save_checkpoint(
                    epoch, model, optimizer, scheduler, train_losses, best_loss,
                    "improved_3d_diffusion_128_best_model.pth"
                )

            # 每10个epoch保存一次检查点
            if epoch % 10 == 0:
                save_checkpoint(
                    epoch, model, optimizer, scheduler, train_losses, best_loss,
                    f"improved_3d_diffusion_128_checkpoint_epoch_{epoch}.pth"
                )
                save_training_log(train_losses, training_config)

            # 每20个epoch生成一次样本
            if epoch % 20 == 0:
                try:
                    with torch.no_grad():
                        samples = trainer.sample((in_channels, 128, 128, 128), num_samples=1)
                        sample_volume = samples[0].cpu().numpy()

                        # 反归一化
                        sample_volume_uint8 = (sample_volume * 255).clip(0, 255).astype(np.uint8)

                        # 可视化样本切片
                        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
                        depths = [32, 64, 96]
                        for i, depth in enumerate(depths):
                            if in_channels == 1:
                                axes[i].imshow(sample_volume_uint8[0, depth], cmap='gray')
                            elif in_channels == 3:
                                rgb_slice = np.transpose(sample_volume_uint8[:, depth], (1, 2, 0))
                                axes[i].imshow(rgb_slice)
                            else:
                                axes[i].imshow(sample_volume_uint8[0, depth], cmap='gray')

                            axes[i].set_title(f"Sample Depth: {depth}")
                            axes[i].axis('off')

                        plt.suptitle(f"Epoch {epoch} - Generated 128×128×128 Sample")
                        plt.savefig(
                            os.path.join(VISUALIZATION_DIR, f"improved_generated_128_sample_epoch_{epoch}.png"),
                            bbox_inches='tight', dpi=150
                        )
                        plt.close()

                        # 保存生成的样本数据
                        sample_save_path = os.path.join(VISUALIZATION_DIR,
                                                        f"improved_generated_sample_epoch_{epoch}.npz")
                        np.savez_compressed(sample_save_path, volume=sample_volume_uint8)
                        print(f"生成样本已保存: {sample_save_path}")

                except Exception as e:
                    print(f"生成样本时出错: {e}")

            # 清理内存
            torch.cuda.empty_cache()

        except Exception as e:
            print(f"Epoch {epoch} 训练出错: {e}")
            torch.cuda.empty_cache()
            continue

    # 最终保存
    save_checkpoint(
        EPOCHS, model, optimizer, scheduler, train_losses, best_loss,
        "improved_3d_diffusion_128_final_model.pth"
    )
    save_training_log(train_losses, training_config)

    print(f"训练完成！所有文件已保存到: {SAVE_DIR}")


if __name__ == "__main__":
    print("开始训练改进的128×128×128 3D扩散模型...")

    # 建议先禁用数据增强进行测试
    train_improved_3d_diffusion_model_128()

    print("改进的128×128×128 3D扩散模型训练完成！")