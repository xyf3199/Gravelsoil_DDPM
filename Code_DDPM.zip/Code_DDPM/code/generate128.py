import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import json
from tqdm import tqdm
import matplotlib.pyplot as plt

# ============== 定义路径 ==============
SAVE_DIR = "/mnt/PyCharm_Project_4/improved_3d_training11/ablation_more_channels"
CHECKPOINT_DIR = os.path.join(SAVE_DIR, "checkpoints")
GENERATED_SAMPLES_DIR = os.path.join(SAVE_DIR, "generated_samples")

# 创建生成样本目录
os.makedirs(GENERATED_SAMPLES_DIR, exist_ok=True)


# 加载模型定义（保持与训练代码一致，注意 base_channels 已改为64）
class TimeEmbedding(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.dim = dim
        self.proj = nn.Sequential(
            nn.Linear(dim, dim * 2),
            nn.SiLU(),
            nn.Linear(dim * 2, dim)
        )

    def forward(self, timesteps):
        half_dim = self.dim // 2
        emb = torch.log(torch.tensor(10000.0)) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, device=timesteps.device) * -emb)
        emb = timesteps[:, None] * emb[None, :]
        emb = torch.cat([torch.sin(emb), torch.cos(emb)], dim=-1)
        return self.proj(emb)


class ResidualBlock3D(nn.Module):
    def __init__(self, in_channels, out_channels, time_emb_dim=None):
        super().__init__()
        self.time_emb_dim = time_emb_dim

        self.conv1 = nn.Conv3d(in_channels, out_channels, 3, padding=1)
        self.norm1 = nn.GroupNorm(8, out_channels)
        self.conv2 = nn.Conv3d(out_channels, out_channels, 3, padding=1)
        self.norm2 = nn.GroupNorm(8, out_channels)

        if in_channels != out_channels:
            self.shortcut = nn.Conv3d(in_channels, out_channels, 1)
        else:
            self.shortcut = nn.Identity()

        if time_emb_dim is not None:
            self.time_emb_proj = nn.Linear(time_emb_dim, out_channels)

        self.activation = nn.SiLU()

    def forward(self, x, t_emb=None):
        residual = self.shortcut(x)

        x = self.conv1(x)
        x = self.norm1(x)

        if t_emb is not None and self.time_emb_dim is not None:
            t_emb = self.time_emb_proj(self.activation(t_emb))
            t_emb = t_emb.view(t_emb.shape[0], t_emb.shape[1], 1, 1, 1)
            x = x + t_emb

        x = self.activation(x)
        x = self.conv2(x)
        x = self.norm2(x)

        return self.activation(x + residual)


class ThreeDUNet128(nn.Module):
    # 注意：训练时使用了 base_channels=64，这里保持默认值以便加载
    def __init__(self, in_channels=3, base_channels=64, time_emb_dim=128):
        super(ThreeDUNet128, self).__init__()

        self.time_emb_dim = time_emb_dim
        self.time_embed = TimeEmbedding(time_emb_dim)

        self.enc1 = ResidualBlock3D(in_channels, base_channels, time_emb_dim)
        self.enc2 = ResidualBlock3D(base_channels, base_channels * 2, time_emb_dim)
        self.enc3 = ResidualBlock3D(base_channels * 2, base_channels * 4, time_emb_dim)
        self.enc4 = ResidualBlock3D(base_channels * 4, base_channels * 8, time_emb_dim)

        self.mid1 = ResidualBlock3D(base_channels * 8, base_channels * 8, time_emb_dim)
        self.mid2 = ResidualBlock3D(base_channels * 8, base_channels * 8, time_emb_dim)

        self.dec4 = ResidualBlock3D(base_channels * 12, base_channels * 4, time_emb_dim)
        self.dec3 = ResidualBlock3D(base_channels * 6, base_channels * 2, time_emb_dim)
        self.dec2 = ResidualBlock3D(base_channels * 3, base_channels, time_emb_dim)
        self.dec1 = ResidualBlock3D(base_channels, base_channels, time_emb_dim)

        self.final_conv = nn.Conv3d(base_channels, in_channels, kernel_size=1)

        self.downsample = nn.MaxPool3d(2)
        self.upsample = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=True)

    def forward(self, x, timesteps):
        t_emb = self.time_embed(timesteps)

        e1 = self.enc1(x, t_emb)
        e2 = self.enc2(self.downsample(e1), t_emb)
        e3 = self.enc3(self.downsample(e2), t_emb)
        e4 = self.enc4(self.downsample(e3), t_emb)

        m = self.mid1(e4, t_emb)
        m = self.mid2(m, t_emb)

        up_m = self.upsample(m)
        d4 = self.dec4(torch.cat([up_m, e3], dim=1), t_emb)

        up_d4 = self.upsample(d4)
        d3 = self.dec3(torch.cat([up_d4, e2], dim=1), t_emb)

        up_d3 = self.upsample(d3)
        d2 = self.dec2(torch.cat([up_d3, e1], dim=1), t_emb)

        d1 = self.dec1(d2, t_emb)
        return self.final_conv(d1)


class Diffusion3DGenerator128:
    """3D扩散模型生成器（修复亮度问题）"""

    def __init__(self, model, device, T=1000, beta_start=1e-4, beta_end=0.02):
        self.model = model.to(device)
        self.device = device
        self.T = T

        # 关键修改：统一使用线性噪声调度（与训练时一致）
        self.betas = torch.linspace(beta_start, beta_end, T).to(device)
        self.alphas = 1. - self.betas
        self.alphas_cumprod = torch.cumprod(self.alphas, dim=0)
        self.alphas_cumprod_prev = F.pad(self.alphas_cumprod[:-1], (1, 0), value=1.0)

        # 预计算采样系数
        self.sqrt_alphas_cumprod = torch.sqrt(self.alphas_cumprod)
        self.sqrt_one_minus_alphas_cumprod = torch.sqrt(1. - self.alphas_cumprod)
        self.sqrt_recip_alphas = torch.sqrt(1.0 / self.alphas)
        self.posterior_variance = self.betas * (1. - self.alphas_cumprod_prev) / (1. - self.alphas_cumprod)

    def sample(self, shape, num_samples=1, progress_bar=True, brightness_boost=1.0):
        """
        采样生成新的3D块
        :param brightness_boost: 亮度增强系数（>1增强亮度，建议1.0-1.3）
        """
        self.model.eval()
        with torch.no_grad():
            # 从纯噪声开始
            x = torch.randn((num_samples, *shape), device=self.device)

            # 创建进度条
            iterator = tqdm(range(self.T - 1, -1, -1), desc="生成进度") if progress_bar else range(self.T - 1, -1, -1)

            for t in iterator:
                t_batch = torch.full((num_samples,), t, device=self.device, dtype=torch.long)
                predicted_noise = self.model(x, t_batch)

                # 计算采样系数
                alpha = self.alphas[t]
                alpha_cumprod = self.alphas_cumprod[t]
                beta = self.betas[t]
                sqrt_recip_alpha = self.sqrt_recip_alphas[t]
                sqrt_one_minus_alpha_cumprod = self.sqrt_one_minus_alphas_cumprod[t]

                # 计算均值
                model_mean = sqrt_recip_alpha * (
                        x - beta * predicted_noise / sqrt_one_minus_alpha_cumprod
                )

                if t == 0:
                    x = model_mean
                else:
                    posterior_variance = self.posterior_variance[t]
                    noise = torch.randn_like(x)
                    x = model_mean + torch.sqrt(posterior_variance) * noise

                # 每100步清理一次内存
                if t % 100 == 0:
                    torch.cuda.empty_cache()

            # 应用亮度增强（在归一化前）
            x = x * brightness_boost
            return x


def load_model(checkpoint_path, device, in_channels=3):
    """加载训练好的模型（使用 base_channels=64 以匹配训练）"""
    # 显式指定 base_channels=64，因为训练时使用的是64通道模型
    model = ThreeDUNet128(in_channels=in_channels, base_channels=64)
    checkpoint = torch.load(checkpoint_path, map_location=device)

    # 检查检查点中是否有模型状态字典
    if 'model_state_dict' in checkpoint:
        model.load_state_dict(checkpoint['model_state_dict'])
        print(f"模型已从 {checkpoint_path} 加载")
        if 'epoch' in checkpoint:
            print(f"训练信息: Epoch {checkpoint['epoch']}")
        if 'best_loss' in checkpoint:
            print(f"最佳损失: {checkpoint['best_loss']:.6f}")
    else:
        # 如果检查点直接是模型状态字典
        model.load_state_dict(checkpoint)
        print(f"模型已从 {checkpoint_path} 加载（直接状态字典）")

    generator = Diffusion3DGenerator128(model, device, T=1000)
    return generator


def save_generated_sample(sample, filename, output_dir, apply_brightness_stretch=True):
    """保存生成的样本，添加亮度拉伸处理"""
    if torch.is_tensor(sample):
        sample = sample.cpu().numpy()

    # 关键修改1：亮度拉伸（将数据强制映射到[0,1]范围）
    if apply_brightness_stretch:
        min_val = sample.min()
        max_val = sample.max()
        # 避免除零错误
        if max_val - min_val < 1e-8:
            sample_normalized = np.zeros_like(sample)
        else:
            sample_normalized = (sample - min_val) / (max_val - min_val)
    else:
        # 直接裁剪到[0,1]
        sample_normalized = np.clip(sample, 0, 1)

    # 转换为uint8
    sample_uint8 = (sample_normalized * 255).clip(0, 255).astype(np.uint8)

    # 保存为npz文件
    filepath = os.path.join(output_dir, filename)
    np.savez_compressed(filepath, volume=sample_uint8)
    return filepath


def visualize_sample(sample, filename, output_dir, apply_brightness_stretch=True):
    """可视化样本切片，优化亮度显示"""
    if torch.is_tensor(sample):
        sample = sample.cpu().numpy()

    # 关键修改2：可视化前也应用相同的亮度拉伸
    if apply_brightness_stretch:
        min_val = sample.min()
        max_val = sample.max()
        if max_val - min_val < 1e-8:
            sample_normalized = np.zeros_like(sample)
        else:
            sample_normalized = (sample - min_val) / (max_val - min_val)
    else:
        sample_normalized = np.clip(sample, 0, 1)

    sample_uint8 = (sample_normalized * 255).clip(0, 255).astype(np.uint8)

    # 可视化中间切片
    plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    depths = [32, 64, 96]  # 选择中间区域的切片

    for i, depth in enumerate(depths):
        if sample_uint8.shape[0] == 1:  # 灰度图
            axes[i].imshow(sample_uint8[0, depth], cmap='gray')
        elif sample_uint8.shape[0] == 3:  # RGB图
            rgb_slice = np.transpose(sample_uint8[:, depth], (1, 2, 0))
            axes[i].imshow(rgb_slice)
        else:
            axes[i].imshow(sample_uint8[0, depth], cmap='gray')
        axes[i].set_title(f"深度切片: {depth}")
        axes[i].axis('off')

    plt.suptitle(f"生成样本: {filename}")
    plt.tight_layout()

    # 保存可视化图片
    vis_path = os.path.join(output_dir, f"{os.path.splitext(filename)[0]}_visualization.png")
    plt.savefig(vis_path, bbox_inches='tight', dpi=150)
    plt.close()
    return vis_path


def generate_3d_blocks():
    """生成3D块文件（优化亮度版本）"""
    # 配置参数
    DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    # 修改为指定的模型路径
    CHECKPOINT_PATH = "/mnt/PyCharm_Project_4/improved_3d_training11/ablation_more_channels/checkpoints/checkpoint_epoch_200.pth"
    NUM_SAMPLES = 20
    IN_CHANNELS = 3  # 根据训练数据调整（3=RGB, 1=灰度）
    BRIGHTNESS_BOOST = 1.3  # 亮度增强系数（可调整，建议1.0-1.3）
    APPLY_STRETCH = True  # 是否应用亮度拉伸

    print(f"使用设备: {DEVICE}")
    print(f"检查点路径: {CHECKPOINT_PATH}")
    print(f"生成样本数量: {NUM_SAMPLES}")
    print(f"亮度增强系数: {BRIGHTNESS_BOOST}")
    print(f"输出目录: {GENERATED_SAMPLES_DIR}")

    # 检查检查点文件
    if not os.path.exists(CHECKPOINT_PATH):
        print(f"错误: 检查点文件不存在: {CHECKPOINT_PATH}")
        return

    # 加载模型（注意：load_model 中已使用 base_channels=64）
    print("正在加载模型...")
    generator = load_model(CHECKPOINT_PATH, DEVICE, IN_CHANNELS)

    # 生成样本
    print("开始生成3D块...")
    all_samples = []
    batch_size = 2  # 根据GPU内存调整

    for batch_idx in range(0, NUM_SAMPLES, batch_size):
        current_batch_size = min(batch_size, NUM_SAMPLES - batch_idx)
        print(f"生成批次 {batch_idx // batch_size + 1}/{(NUM_SAMPLES + batch_size - 1) // batch_size}")

        with torch.no_grad():
            # 生成时应用亮度增强
            samples = generator.sample(
                shape=(IN_CHANNELS, 128, 128, 128),
                num_samples=current_batch_size,
                progress_bar=True,
                brightness_boost=BRIGHTNESS_BOOST
            )

        all_samples.extend([samples[i] for i in range(current_batch_size)])
        torch.cuda.empty_cache()

    # 保存生成的样本
    print("正在保存生成的样本...")
    saved_files = []

    for i, sample in enumerate(all_samples):
        filename = f"generated_3d_block_{i + 1:03d}.npz"
        # 保存时应用亮度拉伸
        filepath = save_generated_sample(
            sample, filename, GENERATED_SAMPLES_DIR,
            apply_brightness_stretch=APPLY_STRETCH
        )
        saved_files.append(filepath)

        # 可视化时也应用亮度拉伸
        vis_path = visualize_sample(
            sample, filename, GENERATED_SAMPLES_DIR,
            apply_brightness_stretch=APPLY_STRETCH
        )

        print(f"样本 {i + 1:02d}: {filename} (可视化: {os.path.basename(vis_path)})")

    # 生成汇总信息
    summary_info = {
        "total_generated": NUM_SAMPLES,
        "model_checkpoint": CHECKPOINT_PATH,
        "brightness_boost": BRIGHTNESS_BOOST,
        "apply_brightness_stretch": APPLY_STRETCH,
        "output_directory": GENERATED_SAMPLES_DIR,
        "sample_shape": (IN_CHANNELS, 128, 128, 128),
        "generated_files": [os.path.basename(f) for f in saved_files],
        "timestamp": str(np.datetime64('now'))
    }

    summary_path = os.path.join(GENERATED_SAMPLES_DIR, "generation_summary.json")
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary_info, f, indent=2, ensure_ascii=False)

    print(f"\n生成完成！所有文件保存在: {GENERATED_SAMPLES_DIR}")


if __name__ == "__main__":
    print("开始生成3D块样本（64通道模型版本）...")
    generate_3d_blocks()
    print("生成过程完成！")