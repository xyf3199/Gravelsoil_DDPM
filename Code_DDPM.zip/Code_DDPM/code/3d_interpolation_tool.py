import os
import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm
import matplotlib.pyplot as plt
import argparse
import sys

# ============== 定义保存路径 ==============
SAVE_DIR = "/mnt/PyCharm_Project_4/improved_3d_training1"
CHECKPOINT_DIR = os.path.join(SAVE_DIR, "checkpoints")
VISUALIZATION_DIR = os.path.join(SAVE_DIR, "visualizations")

# 创建所有必要的目录
os.makedirs(SAVE_DIR, exist_ok=True)
os.makedirs(CHECKPOINT_DIR, exist_ok=True)
os.makedirs(VISUALIZATION_DIR, exist_ok=True)


class ThreeDInterpolator:
    """3D插值器 - 专门用于将128扩展到512，优化细节保留以减少朦胧感"""

    def __init__(self, device=None):
        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = device
        print(f"使用设备: {self.device}")

    def trilinear_upsample(self, volume, scale_factor=4):
        """三线性插值（可能导致轻微模糊，适合平滑过渡但易产生朦胧感）"""
        return F.interpolate(
            volume,
            scale_factor=scale_factor,
            mode='trilinear',
            align_corners=True
        )

    def nearest_upsample(self, volume, scale_factor=4):
        """最近邻插值（推荐）：保留细节和边缘，无平滑，避免朦胧感"""
        return F.interpolate(
            volume,
            scale_factor=scale_factor,
            mode='nearest'
        )

    def bicubic_upsample(self, volume, scale_factor=4):
        """双三次插值（3D近似，平滑较强，可能加重朦胧感）"""
        channels = volume.shape[1]
        upsampled_channels = []

        for c in range(channels):
            channel_data = volume[:, c:c + 1]  # 保持4D (B, 1, D, H, W)
            upsampled = F.interpolate(
                channel_data,
                scale_factor=scale_factor,
                mode='trilinear',  # 3D下用三线性近似双三次
                align_corners=True
            )
            upsampled_channels.append(upsampled)

        return torch.cat(upsampled_channels, dim=1)

    def combined_upsample(self, volume, scale_factor=4):
        """组合插值（推荐）：先最近邻保留细节，再轻微平滑，平衡清晰与自然"""
        # 第一步：最近邻插值到256（保留原始细节和边缘）
        step1 = F.interpolate(
            volume,
            scale_factor=2,
            mode='nearest'
        )

        # 第二步：三线性插值到512（轻微平滑减少块状感，不破坏细节）
        step2 = F.interpolate(
            step1,
            scale_factor=2,
            mode='trilinear',
            align_corners=True
        )

        return step2

    def progressive_upsample(self, volume, target_size=512, steps=2):
        """渐进式上采样（分步放大，可调整平滑程度）"""
        current_volume = volume

        for step in range(steps):
            current_size = current_volume.shape[2]  # D, H, W 相同
            next_size = current_size * 2

            if next_size > target_size:
                next_size = target_size

            # 优先用最近邻保留细节，如需平滑可改为trilinear
            current_volume = F.interpolate(
                current_volume,
                size=(next_size, next_size, next_size),
                mode='nearest',  # 此处修改为nearest以减少模糊
                align_corners=True
            )

            print(f"渐进上采样步骤 {step + 1}: {current_size}→{next_size}")

        return current_volume

    def upsample_single_volume(self, volume_128, method='nearest', target_size=512):
        """
        对单个128体积进行上采样（默认使用nearest减少朦胧感）
        """
        # 确保输入是torch tensor且格式正确
        if isinstance(volume_128, np.ndarray):
            # 处理不同输入形状 (C, D, H, W) 或 (D, H, W, C) 或 (D, H, W)
            if volume_128.ndim == 4 and volume_128.shape[-1] in [1, 3, 4]:  # (D, H, W, C)
                volume_128 = torch.from_numpy(volume_128).permute(3, 0, 1, 2).float()
            elif volume_128.ndim == 4:  # (C, D, H, W)
                volume_128 = torch.from_numpy(volume_128).float()
            elif volume_128.ndim == 3:  # (D, H, W)
                volume_128 = torch.from_numpy(volume_128).unsqueeze(0).float()
            else:
                raise ValueError(f"不支持的输入形状: {volume_128.shape}")

        # 添加batch维度
        if volume_128.dim() == 4:
            volume_128 = volume_128.unsqueeze(0)

        volume_128 = volume_128.to(self.device)

        # 应用选择的插值方法
        if method == 'trilinear':
            volume_512 = self.trilinear_upsample(volume_128, scale_factor=target_size // 128)
        elif method == 'nearest':
            volume_512 = self.nearest_upsample(volume_128, scale_factor=target_size // 128)
        elif method == 'bicubic':
            volume_512 = self.bicubic_upsample(volume_128, scale_factor=target_size // 128)
        elif method == 'combined':
            volume_512 = self.combined_upsample(volume_128, scale_factor=target_size // 128)
        elif method == 'progressive':
            volume_512 = self.progressive_upsample(volume_128, target_size=target_size)
        else:
            raise ValueError(f"不支持的插值方法: {method}")

        # 移除batch维度并转换为numpy
        volume_512 = volume_512.squeeze(0).cpu().numpy()

        return volume_512

    def upsample_batch(self, volumes_128, method='nearest', target_size=512):
        """批量上采样（默认使用nearest方法）"""
        volumes_512 = []

        for i, volume in enumerate(tqdm(volumes_128, desc="批量上采样")):
            volume_512 = self.upsample_single_volume(volume, method, target_size)
            volumes_512.append(volume_512)

        return volumes_512


class VolumeVisualizer:
    """体积可视化器（增强细节对比展示）"""

    def __init__(self, save_dir=VISUALIZATION_DIR):
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

    def visualize_comparison(self, volume_128, volume_512, title="分辨率对比", filename="comparison.png"):
        """可视化128和512体积的对比，突出细节差异"""
        # 确保输入是numpy数组
        if isinstance(volume_128, torch.Tensor):
            volume_128 = volume_128.cpu().numpy()
        if isinstance(volume_512, torch.Tensor):
            volume_512 = volume_512.cpu().numpy()

        # 处理通道格式为 (D, H, W, C) 以便可视化
        if volume_128.ndim == 4 and volume_128.shape[0] in [1, 3, 4]:  # (C, D, H, W)
            volume_128 = np.transpose(volume_128, (1, 2, 3, 0))
        if volume_512.ndim == 4 and volume_512.shape[0] in [1, 3, 4]:  # (C, D, H, W)
            volume_512 = np.transpose(volume_512, (1, 2, 3, 0))

        fig, axes = plt.subplots(2, 3, figsize=(15, 10))

        # 128样本切片（选择细节丰富的深度）
        depths_128 = [volume_128.shape[0] // 4, volume_128.shape[0] // 2, volume_128.shape[0] * 3 // 4]
        for i, depth in enumerate(depths_128):
            depth = min(depth, volume_128.shape[0] - 1)
            if volume_128.shape[-1] == 1:  # 灰度
                axes[0, i].imshow(volume_128[depth, :, :, 0], cmap='gray', vmin=0, vmax=1)  # 固定对比度
            elif volume_128.shape[-1] == 3:  # RGB
                axes[0, i].imshow(volume_128[depth, :, :, :])
            else:
                axes[0, i].imshow(volume_128[depth, :, :, 0], cmap='gray', vmin=0, vmax=1)
            axes[0, i].set_title(f"128×128×128 - 深度 {depth}")
            axes[0, i].axis('off')

        # 512样本切片（与128对应深度，便于对比细节）
        depths_512 = [volume_512.shape[0] // 4, volume_512.shape[0] // 2, volume_512.shape[0] * 3 // 4]
        for i, depth in enumerate(depths_512):
            depth = min(depth, volume_512.shape[0] - 1)
            if volume_512.shape[-1] == 1:  # 灰度
                axes[1, i].imshow(volume_512[depth, :, :, 0], cmap='gray', vmin=0, vmax=1)  # 固定对比度，突出细节
            elif volume_512.shape[-1] == 3:  # RGB
                axes[1, i].imshow(volume_512[depth, :, :, :])
            else:
                axes[1, i].imshow(volume_512[depth, :, :, 0], cmap='gray', vmin=0, vmax=1)
            axes[1, i].set_title(f"512×512×512 - 深度 {depth}")
            axes[1, i].axis('off')

        plt.suptitle(title)
        plt.tight_layout()
        plt.savefig(os.path.join(self.save_dir, filename), bbox_inches='tight', dpi=200)  # 提高DPI，更清晰展示细节
        plt.close()
        print(f"对比图已保存: {filename}")


def load_npz_volume(file_path):
    """加载NPZ文件中的体积数据"""
    data = np.load(file_path)
    if 'volume' in data:
        return data['volume']
    else:
        # 尝试找到包含体积数据的键
        for key in data.keys():
            if data[key].ndim >= 3:  # 寻找3D或4D数组
                return data[key]
        raise ValueError(f"在文件 {file_path} 中找不到体积数据")


def save_volume(volume, file_path):
    """保存体积数据到NPZ文件"""
    np.savez_compressed(file_path, volume=volume)
    print(f"体积数据已保存: {file_path}")


def interpolate_single_file(input_path, output_path, method='nearest', target_size=512, visualize=True):
    """对单个文件进行插值（默认使用nearest方法）"""
    print(f"处理文件: {input_path}")

    # 初始化插值器和可视化器
    interpolator = ThreeDInterpolator()
    visualizer = VolumeVisualizer()

    try:
        # 加载128体积
        volume_128 = load_npz_volume(input_path)
        print(f"输入体积形状: {volume_128.shape}")

        # 上采样到512
        volume_512 = interpolator.upsample_single_volume(
            volume_128,
            method=method,
            target_size=target_size
        )
        print(f"输出体积形状: {volume_512.shape}")

        # 保存结果
        save_volume(volume_512, output_path)

        # 生成可视化对比（突出细节）
        if visualize:
            base_name = os.path.splitext(os.path.basename(input_path))[0]
            visualizer.visualize_comparison(
                volume_128,
                volume_512,
                title=f"{base_name} - {method}插值（细节对比）",
                filename=f"{base_name}_{method}_detail_comparison.png"
            )

        return volume_512

    except Exception as e:
        print(f"处理文件 {input_path} 时出错: {e}")
        return None


def interpolate_directory(input_dir, output_dir, method='nearest', target_size=512, visualize=True):
    """对目录中的所有NPZ文件进行插值（默认使用nearest方法）"""
    print(f"处理目录: {input_dir}")

    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)

    # 查找所有NPZ文件
    npz_files = [f for f in os.listdir(input_dir) if f.endswith('.npz')]
    print(f"找到 {len(npz_files)} 个NPZ文件")

    if len(npz_files) == 0:
        print("在输入目录中未找到NPZ文件")
        return

    # 批量处理文件
    for filename in tqdm(npz_files, desc="处理文件"):
        input_path = os.path.join(input_dir, filename)
        output_path = os.path.join(output_dir, filename)

        interpolate_single_file(input_path, output_path, method, target_size, visualize)


def main():
    """主函数（默认使用清晰化插值方法）"""
    parser = argparse.ArgumentParser(description='3D体积插值工具 - 减少朦胧感，保留细节')
    parser.add_argument('--input', type=str, required=True,
                        help='输入文件或目录路径')
    parser.add_argument('--output', type=str, required=True,
                        help='输出文件或目录路径')
    parser.add_argument('--method', type=str,
                        choices=['trilinear', 'nearest', 'bicubic', 'combined', 'progressive'],
                        default='nearest',  # 默认使用最近邻，减少朦胧感
                        help='插值方法（推荐nearest或combined）')
    parser.add_argument('--target_size', type=int, default=512,
                        help='目标尺寸 (默认: 512)')
    parser.add_argument('--no_visualize', action='store_true',
                        help='不生成可视化对比图')

    args = parser.parse_args()

    # 检查输入路径是否存在
    if not os.path.exists(args.input):
        print(f"错误: 输入路径不存在: {args.input}")
        return

    # 确定是文件还是目录
    if os.path.isfile(args.input):
        # 处理单个文件
        interpolate_single_file(
            args.input,
            args.output,
            method=args.method,
            target_size=args.target_size,
            visualize=not args.no_visualize
        )
    elif os.path.isdir(args.input):
        # 处理目录
        interpolate_directory(
            args.input,
            args.output,
            method=args.method,
            target_size=args.target_size,
            visualize=not args.no_visualize
        )
    else:
        print(f"错误: 输入路径既不是文件也不是目录: {args.input}")


if __name__ == "__main__":
    print("3D体积插值工具（优化版）- 减少朦胧感，保留细节")
    print("=" * 60)

    # 直接设置参数（推荐优先测试nearest，再测试combined）
    input_path = "/mnt/PyCharm_Project_4/improved_3d_training1/generated_samples"
    output_path = "/mnt/PyCharm_Project_4/128-512"
    method = "nearest"  # 优先使用此方法，若有轻微块状感可改为"combined"

    if os.path.isdir(input_path):
        interpolate_directory(
            input_path,
            output_path,
            method=method,
            target_size=512,
            visualize=True  # 生成对比图，便于观察细节效果
        )
    else:
        print(f"输入路径不存在或不是目录: {input_path}")

    print("插值处理完成！")