#!/usr/bin/env python3
import re
import os
import argparse
import numpy as np
import pandas as pd
from pathlib import Path
from typing import List, Tuple, Dict, Optional
from tqdm import tqdm
from skimage.filters import threshold_otsu
from skimage.measure import euler_number as sk_euler_number
from scipy.ndimage import zoom
import matplotlib.pyplot as plt
import zipfile  # 新增：用于文件校验

# -------------------------- 1. 新增：文件校验函数（来自第一段代码，保证批量处理稳定性） --------------------------
def check_file_validity(path: str) -> bool:
    """检查文件是否为有效的NPZ文件"""
    try:
        if os.path.getsize(path) == 0:
            print(f"  [WARNING] 文件为空: {path}")
            return False
        if not zipfile.is_zipfile(path):
            print(f"  [WARNING] 不是有效的ZIP/NPZ文件: {path}")
            return False
        with open(path, 'rb') as f:
            header = f.read(100)
            if header[:4] != b'PK\x03\x04':
                print(f"  [WARNING] 无效的ZIP文件头: {path}")
                return False
        return True
    except Exception as e:
        print(f"  [WARNING] 文件检查失败 {path}: {e}")
        return False

def safe_load_npz(path: str) -> Optional[np.ndarray]:
    """安全加载NPZ，避免单个文件损坏导致批量处理中断"""
    try:
        if not check_file_validity(path):
            return None
        data = np.load(path, allow_pickle=True)
        keys = list(sorted(data.keys()))
        if not keys:
            print(f"  [WARNING] NPZ文件中没有数组: {path}")
            return None
        arr = data[keys[0]]
        arr = np.asarray(arr)
        if arr.ndim == 4:
            if arr.shape[0] in (1, 3, 4):
                arr = np.moveaxis(arr, 0, -1)
        elif arr.ndim != 3:
            print(f"  [WARNING] 不支持的数组维度 ndim={arr.ndim} in {path}")
            return None
        print(f"  ✓ 成功加载数组, 形状: {arr.shape}, 数据类型: {arr.dtype}")
        return arr
    except Exception as e:
        print(f"  [ERROR] 无法加载文件 {path}: {e}")
        return None

# -------------------------- 2. 保留第二段代码的核心函数（高采样数逻辑） --------------------------
def to_grayscale_3d(arr: np.ndarray) -> np.ndarray:
    """Convert to grayscale volume normalized to [0,1]."""
    if arr.ndim == 4:
        C = arr.shape[-1]
        if C == 1:
            vol = arr[..., 0]
        else:
            arr = arr.astype(np.float32)
            vol = np.zeros(arr.shape[:-1], dtype=np.float32)
            w = np.array([0.299, 0.587, 0.114], dtype=np.float32)
            if C < 3:
                w = np.ones(C, dtype=np.float32) / C
            for c in range(C):
                ch = arr[..., c]
                p1, p99 = np.percentile(ch, [1, 99])
                if p99 > p1:
                    ch = (ch - p1) / (p99 - p1)
                else:
                    ch = ch - ch.min()
                    denom = ch.max() - ch.min()
                    ch = ch / denom if denom > 0 else ch
                vol += (w[c if c < len(w) else -1] if C >= 3 else w[c]) * ch.astype(np.float32)
            vol = np.clip(vol, 0.0, 1.0)
    else:
        vol = arr.astype(np.float32)
        p1, p99 = np.percentile(vol, [1, 99])
        if p99 > p1:
            vol = (vol - p1) / (p99 - p1)
        else:
            vol = vol - vol.min()
            d = vol.max() - vol.min()
            vol = vol / d if d > 0 else vol
        vol = np.clip(vol, 0.0, 1.0)
    return vol.astype(np.float32)

def otsu_binarize(vol: np.ndarray, invert: bool = False) -> np.ndarray:
    """Otsu thresholding with optional invert."""
    t = threshold_otsu(vol)
    binv = (vol >= t)
    if invert:
        binv = ~binv
    return binv.astype(np.uint8)

def euler_characteristic(binary: np.ndarray, connectivity: int = 1) -> int:
    """Euler characteristic for 3D volumes."""
    chi = sk_euler_number(binary.astype(bool), connectivity=connectivity)
    return int(chi)

def compute_s2_directional(binary: np.ndarray, max_distance: int = 50, num_samples: int = 5000) -> Dict[str, np.ndarray]:
    """计算三个方向的两点相关函数（高采样数，无多余容错）"""
    I = binary.astype(np.float32)
    shape = I.shape
    phi = np.mean(I)
    print(f"    Computing directional S2 with {num_samples} samples, phi={phi:.3f}")
    results = {}
    for direction, axis in [('X', 2), ('Y', 1), ('Z', 0)]:
        print(f"      {direction} direction...")
        correlations = [phi]
        for r in tqdm(range(1, max_distance + 1), desc=f"S2-{direction}", leave=False):
            if shape[axis] <= r:
                correlations.append(phi ** 2)
                continue
            corr_sum = 0.0
            valid_samples = 0
            for _ in range(num_samples):
                # 移除多余的try-except，保证样本利用率
                if axis == 0:  # Z方向
                    z = np.random.randint(0, shape[0] - r)
                    y = np.random.randint(0, shape[1])
                    x = np.random.randint(0, shape[2])
                    corr_sum += I[z, y, x] * I[z + r, y, x]
                    valid_samples += 1
                elif axis == 1:  # Y方向
                    z = np.random.randint(0, shape[0])
                    y = np.random.randint(0, shape[1] - r)
                    x = np.random.randint(0, shape[2])
                    corr_sum += I[z, y, x] * I[z, y + r, x]
                    valid_samples += 1
                else:  # X方向
                    z = np.random.randint(0, shape[0])
                    y = np.random.randint(0, shape[1])
                    x = np.random.randint(0, shape[2] - r)
                    corr_sum += I[z, y, x] * I[z, y, x + r]
                    valid_samples += 1
            correlations.append(corr_sum / valid_samples if valid_samples > 0 else phi ** 2)
        results[direction] = np.array(correlations)
        print(f"        S2_{direction}(r=0)={correlations[0]:.4f}, S2_{direction}(r={max_distance})={correlations[-1]:.4f}")
    return results

def compute_lineal_path_directional(binary: np.ndarray, max_length: int = 50, num_samples: int = 3000) -> Dict[str, np.ndarray]:
    """计算三个方向的线性路径函数（高采样数，无多余容错）"""
    shape = binary.shape
    print(f"    Computing directional L with {num_samples} samples")
    results = {}
    for direction, axis in [('X', 2), ('Y', 1), ('Z', 0)]:
        print(f"      {direction} direction...")
        path_values = [1.0]
        for length in tqdm(range(1, max_length + 1), desc=f"L-{direction}", leave=False):
            valid_count = 0
            total_count = 0
            for _ in range(num_samples):
                # 移除多余的try-except，保证样本利用率
                if axis == 0 and shape[0] > length:  # Z方向
                    z = np.random.randint(0, shape[0] - length)
                    y = np.random.randint(0, shape[1])
                    x = np.random.randint(0, shape[2])
                    segment = binary[z:z + length + 1, y, x]
                    if np.all(segment):
                        valid_count += 1
                    total_count += 1
                elif axis == 1 and shape[1] > length:  # Y方向
                    z = np.random.randint(0, shape[0])
                    y = np.random.randint(0, shape[1] - length)
                    x = np.random.randint(0, shape[2])
                    segment = binary[z, y:y + length + 1, x]
                    if np.all(segment):
                        valid_count += 1
                    total_count += 1
                elif axis == 2 and shape[2] > length:  # X方向
                    z = np.random.randint(0, shape[0])
                    y = np.random.randint(0, shape[1])
                    x = np.random.randint(0, shape[2] - length)
                    segment = binary[z, y, x:x + length + 1]
                    if np.all(segment):
                        valid_count += 1
                    total_count += 1
            path_values.append(valid_count / total_count if total_count > 0 else 0.0)
        results[direction] = np.array(path_values)
        print(f"        L_{direction}(r=0)={path_values[0]:.4f}, L_{direction}(r={max_length})={path_values[-1]:.4f}")
    return results

def maybe_downsample_binary(binary: np.ndarray, downsample: int = 1) -> np.ndarray:
    """Downsample binary volume if needed."""
    if downsample and downsample > 1:
        factors = tuple(1.0 / float(downsample) for _ in range(3))
        return zoom(binary, zoom=factors, order=0).astype(np.uint8)
    return binary

def plot_directional_functions(out_dir, s2_data, L_data, filename, phi, chi):
    """绘制三个方向的两点相关函数和线性路径函数"""
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial Unicode MS', 'SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    colors = {'X': 'red', 'Y': 'green', 'Z': 'blue'}
    # 绘制S₂(r)
    for direction in ['X', 'Y', 'Z']:
        if direction in s2_data:
            r_values = np.arange(len(s2_data[direction]))
            ax1.plot(r_values, s2_data[direction], label=f'{direction}方向', color=colors[direction], linewidth=2, marker='o', markersize=3)
    ax1.axhline(y=phi, color='black', linestyle='--', alpha=0.7, label=f'φ = {phi:.3f}')
    ax1.axhline(y=phi ** 2, color='gray', linestyle='--', alpha=0.7, label=f'φ² = {phi ** 2:.3f}')
    ax1.set_xlabel('距离 r (voxels)')
    ax1.set_ylabel('S₂(r)')
    ax1.set_title(f'两点相关函数 S₂(r) - 方向比较\n(φ={phi:.3f}, χ={chi})')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    # 绘制L(r)
    for direction in ['X', 'Y', 'Z']:
        if direction in L_data:
            r_values = np.arange(len(L_data[direction]))
            ax2.plot(r_values, L_data[direction], label=f'{direction}方向', color=colors[direction], linewidth=2, marker='s', markersize=3)
    ax2.set_xlabel('路径长度 r (voxels)')
    ax2.set_ylabel('L(r)')
    ax2.set_title(f'线性路径函数 L(r) - 方向比较\n(φ={phi:.3f}, χ={chi})')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    plt.tight_layout()
    plot_path = Path(out_dir) / (Path(filename).stem + "_directional_plots.png")
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    plt.close()
    return str(plot_path)

def save_directional_data(out_dir, s2_data, L_data, chi, phi, filename):
    """保存方向性数据为TXT文件"""
    txt_path = Path(out_dir) / (Path(filename).stem + "_directional_data.txt")
    with open(txt_path, 'w') as f:
        f.write(f"# Directional analysis results for {filename}\n")
        f.write(f"# Volume fraction (phi): {phi:.6f}\n")
        f.write(f"# Euler characteristic (chi): {chi}\n")
        f.write(f"# Date: {pd.Timestamp.now()}\n\n")
        # 写入S₂数据
        for direction in ['X', 'Y', 'Z']:
            if direction in s2_data:
                f.write(f"# Two-point correlation function S2_{direction}(r)\n")
                f.write(f"# r\tS2_{direction}(r)\n")
                for r, s2 in enumerate(s2_data[direction]):
                    f.write(f"{r}\t{s2:.6f}\n")
                f.write("\n")
        # 写入L数据
        for direction in ['X', 'Y', 'Z']:
            if direction in L_data:
                f.write(f"# Lineal path function L_{direction}(r)\n")
                f.write(f"# r\tL_{direction}(r)\n")
                for r, l_val in enumerate(L_data[direction]):
                    f.write(f"{r}\t{l_val:.6f}\n")
                f.write("\n")
    return str(txt_path)

def process_one(path: str, out_dir: str, invert: bool = False,
                downsample_topo: int = 2, downsample_analysis: int = 2,
                s2_max_distance: int = 50, L_max_length: int = 50,
                num_samples: int = 5000, connectivity: int = 1) -> Optional[Dict[str, object]]:
    """处理单个体积文件（融合安全加载+高采样数）"""
    filename = Path(path).name
    print(f"Processing: {filename}")
    if filename.startswith('.'):
        print(f"  [SKIP] 跳过隐藏文件: {filename}")
        return None
    try:
        # 用安全加载函数替代原load_npz_3d，避免批量处理中断
        raw = safe_load_npz(path)
        if raw is None:
            print(f"  [SKIP] 无法加载文件，跳过: {path}")
            return None
        print(f"  Loaded array shape: {raw.shape}")
        vol = to_grayscale_3d(raw)
        binary = otsu_binarize(vol, invert=invert)
        # 拓扑分析
        bin_for_topo = maybe_downsample_binary(binary, downsample_topo)
        chi = euler_characteristic(bin_for_topo, connectivity=connectivity)
        phi = binary.mean(dtype=np.float64)
        print(f"  Euler characteristic: {chi}, Volume fraction: {phi:.3f}")
        # 分析用二值体积
        bin_for_analysis = maybe_downsample_binary(binary, downsample_analysis)
        # 高采样数计算S₂和L函数
        s2_directional = compute_s2_directional(bin_for_analysis, s2_max_distance, num_samples)
        L_directional = compute_lineal_path_directional(bin_for_analysis, L_max_length, num_samples // 2)
        # 保存结果
        out_npz = Path(out_dir) / (Path(path).stem + "_directional_stats.npz")
        np.savez_compressed(str(out_npz),
                            phi=np.array([phi], dtype=np.float32),
                            chi=np.array([chi], dtype=np.int32),
                            **{f"S2_{d}": s2_directional[d].astype(np.float32) for d in ['X', 'Y', 'Z']},
                            **{f"L_{d}": L_directional[d].astype(np.float32) for d in ['X', 'Y', 'Z']})
        plot_path = plot_directional_functions(out_dir, s2_directional, L_directional, path, phi, chi)
        txt_path = save_directional_data(out_dir, s2_directional, L_directional, chi, phi, path)
        print(f"  ✓ 成功保存结果: {out_npz.name}, {plot_path.name}, {txt_path.name}")
        return {
            "path": path, "phi": phi, "chi": chi,
            "s2_X": s2_directional['X'], "s2_Y": s2_directional['Y'], "s2_Z": s2_directional['Z'],
            "L_X": L_directional['X'], "L_Y": L_directional['Y'], "L_Z": L_directional['Z'],
            "out_npz": str(out_npz), "plot_path": plot_path, "txt_path": txt_path
        }
    except KeyboardInterrupt:
        raise
    except Exception as e:
        print(f"  [ERROR] 处理 {path} 时出错: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

# -------------------------- 3. 主函数：补充随机种子（科研可复现）+ 批量处理优化 --------------------------
def main():
    # 配置参数
    input_dir = "/mnt/PyCharm_Project_4/sanwei"  # 替换为你的输入目录
    out_dir = "/mnt/PyCharm_Project_4/sanwei"    # 替换为你的输出目录
    # 核心参数（保持高采样数）
    invert = False
    connectivity = 1
    downsample_topo = 2
    downsample_analysis = 2
    s2_max_distance = 50
    L_max_length = 50
    num_samples = 5000  # 高采样数保证准确性
    # 🌟 科研必备：固定随机种子，确保结果可复现
    np.random.seed(42)  # 任意整数均可，每次运行种子相同则结果相同
    # 创建输出目录
    os.makedirs(out_dir, exist_ok=True)
    print(f"Output directory: {out_dir}")
    # 扫描有效NPZ文件（来自第一段代码的逻辑）
    input_path = Path(input_dir)
    all_npz_files = list(input_path.glob("*.npz"))
    valid_files = [f for f in all_npz_files if not f.name.startswith('.')]
    working_files = [f for f in valid_files if check_file_validity(str(f))]
    print(f"有效文件: {len(working_files)}/{len(all_npz_files)}")
    if not working_files:
        print("❌ 没有找到有效的NPZ文件，程序退出")
        return
    # 批量处理
    rows = []
    successful_count = 0
    for p in tqdm(working_files, desc="Processing volumes"):
        res = process_one(str(p), out_dir, invert, downsample_topo,
                          downsample_analysis, s2_max_distance, L_max_length,
                          num_samples, connectivity)
        if res is not None:
            rows.append(res)
            successful_count += 1
    # 保存汇总CSV
    if rows:
        summary_data = []
        for row in rows:
            summary_row = {
                "path": Path(row["path"]).name,
                "phi": row["phi"], "chi": row["chi"],
                "s2_X_r0": row["s2_X"][0], "s2_X_r10": row["s2_X"][10] if len(row["s2_X"]) > 10 else np.nan,
                "s2_X_r20": row["s2_X"][20] if len(row["s2_X"]) > 20 else np.nan,
                "s2_Y_r0": row["s2_Y"][0], "s2_Y_r10": row["s2_Y"][10] if len(row["s2_Y"]) > 10 else np.nan,
                "s2_Y_r20": row["s2_Y"][20] if len(row["s2_Y"]) > 20 else np.nan,
                "s2_Z_r0": row["s2_Z"][0], "s2_Z_r10": row["s2_Z"][10] if len(row["s2_Z"]) > 10 else np.nan,
                "s2_Z_r20": row["s2_Z"][20] if len(row["s2_Z"]) > 20 else np.nan,
                "L_X_r0": row["L_X"][0], "L_X_r10": row["L_X"][10] if len(row["L_X"]) > 10 else np.nan,
                "L_X_r20": row["L_X"][20] if len(row["L_X"]) > 20 else np.nan,
                "L_Y_r0": row["L_Y"][0], "L_Y_r10": row["L_Y"][10] if len(row["L_Y"]) > 10 else np.nan,
                "L_Y_r20": row["L_Y"][20] if len(row["L_Y"]) > 20 else np.nan,
                "L_Z_r0": row["L_Z"][0], "L_Z_r10": row["L_Z"][10] if len(row["L_Z"]) > 10 else np.nan,
                "L_Z_r20": row["L_Z"][20] if len(row["L_Z"]) > 20 else np.nan,
            }
            summary_data.append(summary_row)
        df = pd.DataFrame(summary_data)
        csv_path = Path(out_dir) / "directional_summary.csv"
        df.to_csv(csv_path, index=False)
        print(f"✓ 保存汇总CSV到: {csv_path}")
        print(f"\n汇总统计 (成功处理: {successful_count}/{len(working_files)}):")
        print(df[["path", "phi", "chi", "s2_X_r0", "s2_X_r20", "L_X_r0", "L_X_r20"]].head())
    else:
        print("❌ 没有生成任何结果")

if __name__ == "__main__":
    main()